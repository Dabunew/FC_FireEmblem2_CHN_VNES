//////////////////////////////////////////////////////////////////////////
//                                                                      //
//      NES Emulation core                                              //
//                                                           Norix      //
//                                               written     2001/02/22 //
//                                               last modify ----/--/-- //
//////////////////////////////////////////////////////////////////////////
#define	WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "typedef.h"
#include "macro.h"

#include "VirtuaNESres.h"

#include "App.h"
#include "Pathlib.h"
#include "Config.h"
#include "Crclib.h"

#include "nes.h"
#include "mmu.h"
#include "cpu.h"
#include "ppu.h"
#include "apu.h"
#include "pad.h"
#include "rom.h"
#include "wnd.h"
#include "mapper.h"

#include "DirectDraw.h"
#include "DirectSound.h"
#include "DirectInput.h"

int SaveBitmapToFile(HBITMAP hbitmap , LPSTR lpfilename);

NESCONFIG NESCONFIG_NTSC = {
	21477270.0f,		// Base clock
	1789772.5f,		// Cpu clock

	262,			// Total scanlines

	1364,			// Scanline total cycles(15.75KHz)

	1024,			// H-Draw cycles
	340,			// H-Blank cycles
	4,			// End cycles

	1364*262,		// Frame cycles
	29830,			// FrameIRQ cycles

	60,			// Frame rate(Be originally 59.94Hz)
	1000.0f/60.0f		// Frame period(ms)
};

NESCONFIG NESCONFIG_PAL = {
	21281364.0f,		// Base clock
	1773447.0f,		// Cpu clock

	312,			// Total scanlines

	1362,			// Scanline total cycles(15.625KHz)

	1024,			// H-Draw cycles
	338,			// H-Blank cycles
	2,			// End cycles

	1362*312,		// Frame cycles
	35469,			// FrameIRQ cycles

	50,			// Frame rate(Hz)
	1000.0f/50.0f		// Frame period(ms)
};

// Pad disp
BYTE	NES::m_PadImg[]  = {
	28, 8,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00,
	0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x00,
	0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x0F, 0x00, 0x0F,
	0x0F, 0x0F, 0x00, 0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x00, 0x0F, 0x0F, 0x0F, 0x0F, 0x00,
	0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x0F, 0x00, 0x0F,
	0x0F, 0x0F, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};
BYTE	NES::m_KeyImg0[] = {
	2, 2,
	0x2A, 0x2A,
	0x2A, 0x2A,
};
BYTE	NES::m_KeyImg1[] = {
	3, 3,
	0x2A, 0x2A, 0x2A,
	0x2A, 0x2A, 0x2A,
};
BYTE	NES::m_KeyImg2[] = {
	4, 4,
	0xFF, 0x2A, 0x2A, 0xFF,
	0x2A, 0x2A, 0x2A, 0x2A,
	0x2A, 0x2A, 0x2A, 0x2A,
	0xFF, 0x2A, 0x2A, 0xFF,
};

//
//
//
NES::NES( const char* fname , CWnd* frame)
{
	parent = frame;

	bFrameIRQ = TRUE;
	FrameIRQ = 0xC0;

	m_bDiskThrottle = FALSE;
	m_CommandRequest = 0;

	m_nSnapNo = 0;

	m_bNsfPlaying = FALSE;

	m_bMoviePlay = m_bMovieRec = FALSE;
	m_fpMovie = NULL;

	cpu = NULL;
	ppu = NULL;
	apu = NULL;
	rom = NULL;
	pad = NULL;
	mapper = NULL;

	SAVERAM_SIZE = 8*1024;	// 8K byte

	// IRQ type
	nIRQtype = 0;

	// NTSC/PAL VideoMode
	bVideoMode = TRUE;

	// Default config
	nescfg = &NESCONFIG_NTSC;

	// Cheat
	CheatInitial();

	try {
		if( !(cpu = new CPU(this)) )
			throw	"Allocating CPU failed.";

		if( !(ppu = new PPU(this)) )
			throw	"Allocating PPU failed.";

		if( !(apu = new APU(this)) )
			throw	"Allocating APU failed.";

		if( !(pad = new PAD(this)) )
			throw	"Allocating PAD failed.";

		if( !(rom = new ROM(fname)) )
			throw	"Allocating ROM failed.";

		if( !(mapper = CreateMapper(this, rom->GetMapperNo())) ) {
			// ���T�|�[�g�̃}�b�p�[�ł�
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_UNSUPPORTMAPPER );
			sprintf( szErrorString, szErrStr, rom->GetMapperNo() );
			throw	szErrorString;
		}

		NesSub_MemoryInitial();
		LoadSRAM();
		LoadDISK();

		Reset();

		// �Q�[���ŗL�̃f�t�H���g�I�v�V������ݒ�(�ݒ�߂����Ɏg����)
		GameOption.defRenderMethod = (INT)GetRenderMethod();
		GameOption.defIRQtype      = (INT)GetIrqType();
		GameOption.defFrameIRQ     = GetFrameIRQmode();
		GameOption.defVideoMode    = GetVideoMode();

		// �ݒ�����[�h���Đݒ肷��(�G���g����������΃f�t�H���g������)
		if( rom->GetMapperNo() != 20 ) {
			GameOption.Load( rom->GetPROM_CRC() );
		} else {
			GameOption.Load( rom->GetGameID(), rom->GetMakerID() );
		}
		SetRenderMethod( (RENDERMETHOD)GameOption.nRenderMethod );
		SetIrqType     ( GameOption.nIRQtype );
		SetFrameIRQmode( GameOption.bFrameIRQ );
		SetVideoMode   ( GameOption.bVideoMode );
	} catch( CHAR* str ) {
		DELETEPTR( cpu );
		DELETEPTR( ppu );
		DELETEPTR( apu );
		DELETEPTR( pad );
		DELETEPTR( rom );
		DELETEPTR( mapper );
		throw	str;
#ifndef	_DEBUG
	} catch( ... ) {
		DELETEPTR( cpu );
		DELETEPTR( ppu );
		DELETEPTR( apu );
		DELETEPTR( pad );
		DELETEPTR( rom );
		DELETEPTR( mapper );

		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

}

NES::~NES()
{
	MovieStop();

	SaveSRAM();
	SaveDISK();

	DELETEPTR( cpu );
	DELETEPTR( ppu );
	DELETEPTR( apu );
	DELETEPTR( pad );
	DELETEPTR( rom );
	DELETEPTR( mapper );

}

void	NES::SetVideoMode( BOOL bMode )
{	
	bVideoMode = bMode;
	if( !bVideoMode ) {
		nescfg = &NESCONFIG_NTSC;
	} else {
		nescfg = &NESCONFIG_PAL;
	}
	apu->SoundSetup();
}

void	NES::Reset()
{
	SaveSRAM();
	SaveDISK();

	// RAM Clear
	::ZeroMemory( RAM,    8*1024 );
	if( rom->GetPROM_CRC() == 0x29401686 ) {	// Minna no Taabou no Nakayoshi Dai Sakusen(J)
		::memset( RAM, 0xFF, sizeof(RAM) );
	}
	::ZeroMemory( CRAM,  32*1024 );
	::ZeroMemory( VRAM,   4*1024 );

	::ZeroMemory( SPRAM, 0x100 );
	::ZeroMemory( BGPAL, 0x10 );
	::ZeroMemory( SPPAL, 0x10 );

	::ZeroMemory( CPUREG, 0x18 );
	::ZeroMemory( PPUREG, 4 );

	bFrameIRQ = TRUE;
	bFrameIRQ_occur = FALSE;
	FrameIRQ = 0xC0;
	FrameIRQ_cycles = 0;

	m_bDiskThrottle = FALSE;

	SetRenderMethod( PRE_RENDER );

	PROM = rom->GetPROM();
	VROM = rom->GetVROM();

	PROM_8K_SIZE  = rom->GetPROM_SIZE()*2;
	PROM_16K_SIZE = rom->GetPROM_SIZE();
	PROM_32K_SIZE = rom->GetPROM_SIZE()/2;

	VROM_1K_SIZE = rom->GetVROM_SIZE()*8;
	VROM_2K_SIZE = rom->GetVROM_SIZE()*4;
	VROM_4K_SIZE = rom->GetVROM_SIZE()*2;
	VROM_8K_SIZE = rom->GetVROM_SIZE();

	// �f�t�H���g�o���N
	if( VROM_8K_SIZE ) {
		SetVROM_8K_Bank( 0 );
	} else {
		SetCRAM_8K_Bank( 0 );
	}

	// �~���[
	if( rom->Is4SCREEN() ) {
		SetVRAM_Mirror( VRAM_MIRROR4 );
	} else if( rom->IsVMIRROR() ) {
		SetVRAM_Mirror( VRAM_VMIRROR );
	} else {
		SetVRAM_Mirror( VRAM_HMIRROR );
	}

	apu->SelectExSound( 0 );

	ppu->Reset();
	mapper->Reset();

	// Trainer
	if( rom->IsTRAINER() ) {
		::memcpy( WRAM+0x1000, rom->GetTRAINER(), 512 );
	}

	pad->Reset();
	cpu->Reset();
	apu->Reset();

	if( rom->IsNSF() ) {
		mapper->Reset();
	}

	base_cycles = emul_cycles = 0;
}

void	NES::SoftReset()
{
	pad->Reset();
	cpu->Reset();
	apu->Reset();

	if( rom->IsNSF() ) {
		mapper->Reset();
	}

	bFrameIRQ_occur = FALSE;
	FrameIRQ = 0xC0;
	FrameIRQ_cycles = 0;

	m_bDiskThrottle = FALSE;

	base_cycles = emul_cycles = 0;
}

void	NES::EmulationCPU( INT basecycles )
{
INT	cycles;

	base_cycles += basecycles;
	cycles = (INT)((base_cycles/12)-emul_cycles);
	if( cycles > 0 ) {
		emul_cycles += cpu->EXEC( cycles );
	}
}

/*
	�`��V�[�P���X
	0		�_�~�[�X�L�������C��(�`�悵�Ȃ�)
	1 - 239		�`��
	240		�_�~�[�X�L�������C��,VBLANK�t���OON
	241		VINT����,NMI����
	242-261		VINT����
	261		VINT����,VBLANK�t���OOFF
*/
void	NES::EmulateFrame( BOOL bDraw )
{
INT	scanline = 0;

	// NSF�v���C���̎�
	if( rom->IsNSF() ) {
		EmulateNSF();
		return;
	}

	// Cheat
	CheatCodeProcess();

	//
	NES_scanline = scanline;

	if( RenderMethod != TILE_RENDER ) {
		bZapper = FALSE;
		while( TRUE ) {
			ppu->SetRenderScanline( scanline );

			if( scanline == 0 ) {
			// �_�~�[�X�L�������C��
				if( RenderMethod < POST_RENDER ) {
					EmulationCPU( nescfg->ScanlineCycles );
					ppu->FrameStart();
					ppu->ScanlineNext();
					mapper->HSync( scanline );
					ppu->ScanlineStart();
				} else {
					EmulationCPU( nescfg->HDrawCycles );
					ppu->FrameStart();
					ppu->ScanlineNext();
					mapper->HSync( scanline );
					EmulationCPU( FETCH_CYCLES*32 );
					ppu->ScanlineStart();
					EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
				}
			} else if( scanline < 240 ) {
				if( RenderMethod < POST_RENDER ) {
					if( RenderMethod == POST_ALL_RENDER )
						EmulationCPU( nescfg->ScanlineCycles );
					if( bDraw ) {
						ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
					} else {
						if( pad->IsZapperMode() && scanline == ZapperY ) {
							ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
						} else {
							if( !ppu->IsSprite0( scanline ) ) {
								ppu->DummyScanline( scanline );
							} else {
								ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
							}
						}
					}
					ppu->ScanlineNext();				// ����̈ʒu�Ń��X�^�[�n�͉�ʂ��Ⴄ
					if( RenderMethod == PRE_ALL_RENDER )
						EmulationCPU( nescfg->ScanlineCycles );
//					ppu->ScanlineNext();				// ����̈ʒu�Ń��X�^�[�n�͉�ʂ��Ⴄ
					mapper->HSync( scanline );
					ppu->ScanlineStart();
				} else {
					if( RenderMethod == POST_RENDER )
						EmulationCPU( nescfg->HDrawCycles );
					if( bDraw ) {
						ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
					} else {
						if( pad->IsZapperMode() && scanline == ZapperY ) {
							ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
						} else {
							if( !ppu->IsSprite0( scanline ) ) {
								ppu->DummyScanline( scanline );
							} else {
								ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
							}
						}
					}
					if( RenderMethod == PRE_RENDER )
						EmulationCPU( nescfg->HDrawCycles );

					ppu->ScanlineNext();
					mapper->HSync( scanline );
					EmulationCPU( FETCH_CYCLES*32 );
					ppu->ScanlineStart();
					EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
				}
			} else if( scanline == 240 ) {
				mapper->VSync();

				if( RenderMethod < POST_RENDER ) {
					EmulationCPU( nescfg->ScanlineCycles );
					mapper->HSync( scanline );
				} else {
					EmulationCPU( nescfg->HDrawCycles );
					mapper->HSync( scanline );
					EmulationCPU( nescfg->HBlankCycles );
				}
			} else if( scanline <= nescfg->TotalScanlines-1 ) {
				// VBLANK����
				if( scanline == nescfg->TotalScanlines-1 ) {
					ppu->VBlankEnd();
				}
				if( RenderMethod < POST_RENDER ) {
					if( scanline == 241 ) {
						ppu->VBlankStart();
						EmulationCPU( 4*12 );
//						if( PPUREG[0]&PPU_VBLANK_BIT ) {
						if( (PPUREG[0]&PPU_VBLANK_BIT) && !rom->IsNSF() ) {
							cpu->NMI();
						}
						EmulationCPU( nescfg->ScanlineCycles-4*12 );
					} else {
						EmulationCPU( nescfg->ScanlineCycles );
					}
					mapper->HSync( scanline );
				} else {
					if( scanline == 241 ) {
						ppu->VBlankStart();
						EmulationCPU( 4*12 );
//						if( PPUREG[0]&PPU_VBLANK_BIT ) {
						if( (PPUREG[0]&PPU_VBLANK_BIT) && !rom->IsNSF() ) {
							cpu->NMI();
						}
						EmulationCPU( nescfg->HDrawCycles-4*12 );
					} else {
						EmulationCPU( nescfg->HDrawCycles );
					}
					mapper->HSync( scanline );
					EmulationCPU( nescfg->HBlankCycles );
				}

				if( scanline == nescfg->TotalScanlines-1 ) {
					break;
				}
			}
			if( pad->IsZapperMode() ) {
				if( scanline == ZapperY )
					bZapper = TRUE;
				else
					bZapper = FALSE;
			}

			scanline++;
			NES_scanline = scanline;
		}
	} else {
		while( TRUE ) {
			ppu->SetRenderScanline( scanline );

			if( scanline == 0 ) {
			// �_�~�[�X�L�������C��
				// H-Draw (4fetches*32)
				EmulationCPU( FETCH_CYCLES*128 );
				ppu->FrameStart();
				ppu->ScanlineNext();
				EmulationCPU( FETCH_CYCLES*16 );
				mapper->HSync( scanline );
				EmulationCPU( FETCH_CYCLES*16 );
				ppu->ScanlineStart();
				EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
			} else if( scanline < 240 ) {
			// �X�N���[���`��(Scanline 1�`239)
				if( bDraw ) {
					ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
					ppu->ScanlineNext();
					EmulationCPU( FETCH_CYCLES*16 );
					mapper->HSync( scanline );
					EmulationCPU( FETCH_CYCLES*16 );
					ppu->ScanlineStart();
					EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
				} else {
					if( pad->IsZapperMode() && scanline == ZapperY ) {
						ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
					} else {
						if( !ppu->IsSprite0( scanline ) ) {
							// H-Draw (4fetches*32)
							EmulationCPU( FETCH_CYCLES*128 );
							ppu->DummyScanline( scanline );
							ppu->ScanlineNext();
							EmulationCPU( FETCH_CYCLES*16 );
							mapper->HSync( scanline );
							EmulationCPU( FETCH_CYCLES*16 );
							ppu->ScanlineStart();
							EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
						} else {
							EmulationCPU( nescfg->HDrawCycles );
							ppu->Scanline( scanline, Config.graphics.bAllSprite, Config.graphics.bLeftClip );
							ppu->ScanlineNext();
							EmulationCPU( FETCH_CYCLES*16 );
							mapper->HSync( scanline );
							EmulationCPU( FETCH_CYCLES*16 );
							ppu->ScanlineStart();
							EmulationCPU( FETCH_CYCLES*10+nescfg->ScanlineEndCycles );
						}
					}
				}
			} else if( scanline == 240 ) {
			// �_�~�[�X�L�������C�� (Scanline 240)
				mapper->VSync();

				EmulationCPU( nescfg->HDrawCycles );
				// H-Sync
				mapper->HSync( scanline );

				EmulationCPU( nescfg->HBlankCycles );
			} else if( scanline <= nescfg->TotalScanlines-1 ) {
			// VBLANK����
				if( scanline == nescfg->TotalScanlines-1 ) {
					ppu->VBlankEnd();
				}
				if( scanline == 241 ) {
					ppu->VBlankStart();
//					if( PPUREG[0]&PPU_VBLANK_BIT ) {
					if( (PPUREG[0]&PPU_VBLANK_BIT) && !rom->IsNSF() ) {
						EmulationCPU( 4*12 );
						cpu->NMI();
						EmulationCPU( nescfg->HDrawCycles-4*12 );
					} else {
						EmulationCPU( nescfg->HDrawCycles );
					}
				} else {
					EmulationCPU( nescfg->HDrawCycles );
				}

				// H-Sync
				mapper->HSync( scanline );

				EmulationCPU( nescfg->HBlankCycles );

				if( scanline == nescfg->TotalScanlines-1 ) {
					break;
				}
			}
			if( pad->IsZapperMode() ) {
				if( scanline == ZapperY )
					bZapper = TRUE;
				else
					bZapper = FALSE;
			}

			scanline++;
			NES_scanline = scanline;
		}
	}

	// Movie pad
	if( Config.movie.bPadDisplay && bDraw ) {
		DrawPad();
	}
}

void	NES::EmulateNSF()
{
R6502	reg;

	ppu->Reset();
	mapper->VSync();

	if( m_bNsfPlaying ) {
		if( m_bNsfInit ) {
			ZEROMEMORY( RAM, sizeof(RAM) );
			ZEROMEMORY( WRAM, 0x2000 );

			apu->Reset();
			apu->Write( 0x4015, 0x1F );
			apu->Write( 0x4017, 0xC0 );
			apu->ExWrite( 0x4080, 0x80 );	// FDS Volume 0
			apu->ExWrite( 0x408A, 0xE8 );	// FDS Envelope Speed

			cpu->GetContext( reg );
			reg.PC = 0x4710;	// Init Address
			reg.A  = (BYTE)m_nNsfSongNo;
			reg.X  = (BYTE)m_nNsfSongMode;
			reg.Y  = 0;
			reg.S  = 0xFF;
			reg.P  = Z_FLAG|R_FLAG|I_FLAG;
			cpu->SetContext( reg );

			// ���S�΍�����˂Ă����ă��[�v��(1�b��)
			for( INT i = 0; i < nescfg->TotalScanlines*60; i++ ) {
				EmulationCPU( nescfg->ScanlineCycles );
				cpu->GetContext( reg );

				// �������[�v�ɓ��������Ƃ��m�F�����甲����
				if( reg.PC == 0x4700 ) {
					break;
				}
			}

			m_bNsfInit = FALSE;
		}

		cpu->GetContext( reg );
		// �������[�v�ɓ����Ă�����Đݒ肷��
		if( reg.PC == 0x4700 ) {
			reg.PC = 0x4720;	// Play Address
			reg.A  = 0;
			reg.S  = 0xFF;
			cpu->SetContext( reg );
		}

		for( INT i = 0; i < nescfg->TotalScanlines; i++ ) {
			EmulationCPU( nescfg->ScanlineCycles );
		}
	} else {
		cpu->GetContext( reg );
		reg.PC = 0x4700;	// �������[�v
		reg.S  = 0xFF;
		cpu->SetContext( reg );

		EmulationCPU( nescfg->ScanlineCycles*nescfg->TotalScanlines );
	}
}

void	NES::SetNsfPlay( INT songno, INT songmode )
{
	m_bNsfPlaying  = TRUE;
	m_bNsfInit     = TRUE;
	m_nNsfSongNo   = songno;
	m_nNsfSongMode = songmode;
}

void	NES::SetNsfStop()
{
	m_bNsfPlaying = FALSE;
	apu->Reset();
}

void	NES::Clock( INT cycles )
{
}

BYTE	NES::Read( WORD addr )
{
	switch( addr>>13 ) {
		case	0x00:	// $0000-$1FFF
			return	RAM[addr&0x07FF];
		case	0x01:	// $2000-$3FFF
			return	ppu->Read( addr&0xE007 );
		case	0x02:	// $4000-$5FFF
			if( addr < 0x4100 ) {
				return	ReadReg( addr );
			} else {
				return	mapper->ReadLow( addr );
			}
			break;
		case	0x03:	// $6000-$7FFF
			return	mapper->ReadLow( addr );
		case	0x04:	// $8000-$9FFF
		case	0x05:	// $A000-$BFFF
		case	0x06:	// $C000-$DFFF
		case	0x07:	// $E000-$FFFF
			return	CPU_MEM_BANK[addr>>13][addr&0x1FFF];
	}

	return	0x00;	// Warning�\�h
}

void	NES::Write( WORD addr, BYTE data )
{
	switch( addr>>13 ) {
		case	0x00:	// $0000-$1FFF
			RAM[addr&0x07FF] = data;
			break;
		case	0x01:	// $2000-$3FFF
			ppu->Write( addr&0xE007, data );
			break;
		case	0x02:	// $4000-$5FFF
			if( addr < 0x4100 ) {
				WriteReg( addr, data );
			} else {
				mapper->WriteLow( addr, data );
			}
			break;
		case	0x03:	// $6000-$7FFF
			mapper->WriteLow( addr, data );
			break;
		case	0x04:	// $8000-$9FFF
		case	0x05:	// $A000-$BFFF
		case	0x06:	// $C000-$DFFF
		case	0x07:	// $E000-$FFFF
			mapper->Write( addr, data );

			GenieCodeProcess();
			break;
	}
}

BYTE	NES::ReadReg( WORD addr )
{
BYTE	data = 0;

	switch( addr & 0xFF ) {
		case 0x00: case 0x01: case 0x02: case 0x03:
		case 0x04: case 0x05: case 0x06: case 0x07:
		case 0x08: case 0x09: case 0x0A: case 0x0B:
		case 0x0C: case 0x0D: case 0x0E: case 0x0F:
		case 0x10: case 0x11: case 0x12: case 0x13:
			return	apu->Read( addr );
			break;
		case	0x15:
//			data = apu->Read( addr )|(bFrameIRQ_occur?0x40:0x00);
//			bFrameIRQ_occur = FALSE;
			data = apu->Read( addr );
			return	data;
			break;

		case	0x14:
			return	addr&0xFF;
			break;

		case	0x16:
			return	pad->Read( addr ) | 0x40;
			break;
		case	0x17:
//			return	pad->Read( addr ) | (bFrameIRQ_occur?0x00:0x40);
			return	pad->Read( addr ) | apu->Read( addr );
			break;
		default:
			return	mapper->ExRead( addr );
			break;
	}
}

void	NES::WriteReg( WORD addr, BYTE data )
{
BYTE	reg = (BYTE)addr;

	switch( addr & 0xFF ) {
		case 0x00: case 0x01: case 0x02: case 0x03:
		case 0x04: case 0x05: case 0x06: case 0x07:
		case 0x08: case 0x09: case 0x0A: case 0x0B:
		case 0x0C: case 0x0D: case 0x0E: case 0x0F:
		case 0x10: case 0x11: case 0x12: case 0x13:
		case 0x15:
			apu->Write( addr, data );
			CPUREG[reg] = data;
			break;

		case	0x14:
			ppu->DMA( data );
//////			cpu->DMA( 512 ); // DMA Pending cycle
			cpu->DMA( 514 ); // DMA Pending cycle
			CPUREG[reg] = data;
			break;

		case	0x16:
			pad->Write( addr, data );
			CPUREG[reg] = data;
			break;
		case	0x17:
//			FrameIRQ_cycles = 0;
//			FrameIRQ = data & 0xC0;
//			bFrameIRQ_occur = FALSE;
			CPUREG[reg] = data;
			pad->Write( addr, data );
			apu->Write( addr, data );
			break;
		// VirtuaNES�ŗL�|�[�g
		case	0x18:
			apu->Write( addr, data );
			break;
		default:
			mapper->ExWrite( addr, data );
			break;
	}
}

void	NES::LoadSRAM()
{
	if( rom->IsNSF() )
		return;

	::ZeroMemory( WRAM, sizeof(WRAM) );

	if( !rom->IsSAVERAM() )
		return;

	string	tempstr;
	if( Config.path.bSavePath ) {
		tempstr = CPathlib::MakePathExt( Config.path.szSavePath, rom->GetRomName(), "sav" );
	} else {
		tempstr = CPathlib::MakePathExt( rom->GetRomPath(), rom->GetRomName(), "sav" );
	}

	FILE*	fp = NULL;
	try
	{
		if( !(fp = ::fopen( tempstr.c_str(), "rb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, tempstr.c_str() );
			throw	szErrorString;
		}

		LONG	size;
		// �t�@�C���T�C�Y�擾
		::fseek( fp, 0, SEEK_END );
		size = ftell( fp );
		::fseek( fp, 0, SEEK_SET );
		if( size <= 128*1024 ) {
			if( ::fread( WRAM, size, 1, fp ) != 1 )
				throw	"File Read error.";
		}

		FCLOSE( fp );
	} catch( CHAR* str ) {
		FCLOSE( fp );
//		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}
}

void	NES::SaveSRAM()
{
INT	i;

	if( rom->IsNSF() )
		return;

	if( !rom->IsSAVERAM() )
		return;

	for( i = 0; i < SAVERAM_SIZE; i++ ) {
		if( WRAM[i] != 0x00 )
			break;
	}

	if( i < SAVERAM_SIZE ) {

		string	tempstr;
		if( Config.path.bSavePath ) {
			CreateDirectory( Config.path.szSavePath, NULL );
			tempstr = CPathlib::MakePathExt( Config.path.szSavePath, rom->GetRomName(), "sav" );
		} else {
			tempstr = CPathlib::MakePathExt( rom->GetRomPath(), rom->GetRomName(), "sav" );
		}

		FILE*	fp = NULL;
		try
		{
			if( !(fp = ::fopen( tempstr.c_str(), "wb" )) ) {
				// xxx �t�@�C�����J���܂���
				LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
				sprintf( szErrorString, szErrStr, tempstr.c_str() );
				throw	szErrorString;
			}

			if( ::fwrite( WRAM, SAVERAM_SIZE, 1, fp ) != 1 ) {
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}

			FCLOSE( fp );
		} catch( CHAR* str ) {
			FCLOSE( fp );
			throw	str;
	#ifndef	_DEBUG
		} catch(...) {
			FCLOSE( fp );
			// �s���ȃG���[���������܂���
			throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
	#endif
		}
	}
}

void	NES::LoadDISK()
{
	if( rom->GetMapperNo() != 20 )
		return;

	BOOL	bExit = FALSE;

	INT	i, j, diskno;
	FILE*	fp = NULL;
	DISKIMGFILEHDR	ifh;
	DISKIMGHDR	hdr;
	LPBYTE		disk;

	WORD	Version;

	string	tempstr;
	if( Config.path.bSavePath ) {
		tempstr = CPathlib::MakePathExt( Config.path.szSavePath, rom->GetRomName(), "dsv" );
	} else {
		tempstr = CPathlib::MakePathExt( rom->GetRomPath(), rom->GetRomName(), "dsv" );
	}

	try
	{
		if( !(fp = ::fopen( tempstr.c_str(), "rb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, tempstr.c_str() );
			throw	szErrorString;
		}

		if( ::fread( &ifh, sizeof(DISKIMGFILEHDR), 1, fp ) != 1 ) {
			// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_READ );
		}

		if( ::memcmp( ifh.ID, "VirtuaNES DI", sizeof(ifh.ID) ) == 0 ) {
			if( ifh.BlockVersion < 0x0100 && ifh.BlockVersion > 0x200 ) {
				// ���Ή��`���ł�
				throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
			}
			Version = ifh.BlockVersion;
		} else {
			// ���Ή��`���ł�
			throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
		}

		if( Version == 0x0100 ) {
		// Ver0.24�ȑO
			if( ifh.DiskNumber > 4 ) {
				// ���Ή��`���ł�
				throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
			}

			for( i = 0; i < (INT)ifh.DiskNumber; i++ ) {
				if( ::fread( &hdr, sizeof(DISKIMGHDR), 1, fp ) != 1 ) {
					if( i == 0 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					} else {
						break;
					}
				}

				if( ::memcmp( hdr.ID, "SIDE0A", sizeof(hdr.ID) ) == 0 ) {
					diskno = 0;
				} else if( ::memcmp( hdr.ID, "SIDE0B", sizeof(hdr.ID) ) == 0 ) {
					diskno = 1;
				} else if( ::memcmp( hdr.ID, "SIDE1A", sizeof(hdr.ID) ) == 0 ) {
					diskno = 2;
				} else if( ::memcmp( hdr.ID, "SIDE1B", sizeof(hdr.ID) ) == 0 ) {
					diskno = 3;
				} else {
					// ���Ή��`���ł�
					throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
				}

				for( j = 0; j < 16; j++ ) {
					if( hdr.DiskTouch[j] ) {
						disk = rom->GetPROM()+16+65500*diskno+(4*1024)*j;
						if( j < 15 ) {
							if( ::fread( disk, 4*1024, 1, fp ) != 1 ) {
								bExit = TRUE;
								// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
								throw	CApp::GetErrorString( IDS_ERROR_READ );
							}
						} else {
							if( ::fread( disk, 4*1024-36, 1, fp ) != 1 ) {
								bExit = TRUE;
								// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
								throw	CApp::GetErrorString( IDS_ERROR_READ );
							}
						}
					}
				}
			}
		} else 
		if( Version == 0x0200 || Version == 0x0210 ) {
			// Ver0.30�ȍ~
			DISKFILEHDR	dfh;
			LPBYTE	lpDisk = rom->GetPROM();
			LPBYTE	lpWrite = rom->GetDISK();
			LONG	DiskSize = 16+65500*rom->GetDiskNo();
			DWORD	pos;
			BYTE	data;

			// ��������FLAG����
			::ZeroMemory( lpWrite, 16+65500*rom->GetDiskNo() );

			// �w�b�_�ǂݒ���
			if( ::fseek( fp, 0, SEEK_SET ) ) {
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}
			if( ::fread( &dfh, sizeof(DISKFILEHDR), 1, fp ) != 1 ) {
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}

			if( Config.emulator.bCrcCheck ) {
				// ���݃��[�h���̃^�C�g���ƈႤ�����`�F�b�N
				if( dfh.ProgID  !=       rom->GetGameID()
				 || dfh.MakerID != (WORD)rom->GetMakerID()
				 || dfh.DiskNo  != (WORD)rom->GetDiskNo() ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}
			}

			for( i = 0; i < dfh.DifferentSize; i++ ) {
				if( ::fread( &pos, sizeof(DWORD), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					bExit = TRUE;
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}
				data = (BYTE)(pos>>24);
				pos &= 0x00FFFFFF;
				if( pos >= 16 && pos < DiskSize ) {
					lpDisk[pos] = data;
					lpWrite[pos] = 0xFF;
				}
			}
		}
		FCLOSE( fp );
	} catch( CHAR* str ) {
		FCLOSE( fp );
		if( bExit )
			throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}
}

void	NES::SaveDISK()
{
	if( rom->GetMapperNo() != 20 )
		return;

	INT	i;
	FILE*	fp = NULL;
	DISKFILEHDR ifh;
	LPBYTE	lpDisk  = rom->GetPROM();
	LPBYTE	lpWrite = rom->GetDISK();
	LONG	DiskSize = 16+65500*rom->GetDiskNo();
	DWORD	data;

	try
	{
		::ZeroMemory( &ifh, sizeof(ifh) );

		::memcpy( ifh.ID, "VirtuaNES DI", sizeof(ifh.ID) );
		ifh.BlockVersion = 0x0210;
		ifh.ProgID  = rom->GetGameID();
		ifh.MakerID = (WORD)rom->GetMakerID();
		ifh.DiskNo  = (WORD)rom->GetDiskNo();

		// ���ᐔ���J�E���g
		for( i = 16; i < DiskSize; i++ ) {
			if( lpWrite[i] )
				ifh.DifferentSize++;
		}

		if( !ifh.DifferentSize )
			return;

		string	tempstr;
		if( Config.path.bSavePath ) {
			::CreateDirectory( Config.path.szSavePath, NULL );
			tempstr = CPathlib::MakePathExt( Config.path.szSavePath, rom->GetRomName(), "dsv" );
		} else {
			tempstr = CPathlib::MakePathExt( rom->GetRomPath(), rom->GetRomName(), "dsv" );
		}

		if( !(fp = ::fopen( tempstr.c_str(), "wb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			::wsprintf( szErrorString, szErrStr, tempstr.c_str() );
			throw	szErrorString;
		}

		if( ::fwrite( &ifh, sizeof(DISKFILEHDR), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}

		for( i = 16; i < DiskSize; i++ ) {
			if( lpWrite[i] ) {
				data = i & 0x00FFFFFF;
				data |= ((DWORD)lpDisk[i]&0xFF)<<24;

				// Write File
				if( ::fwrite( &data, sizeof(DWORD), 1, fp ) != 1 ) {
					// �t�@�C���̏������݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_WRITE );
				}
			}
		}
		FCLOSE( fp );
	} catch( CHAR* str ) {
		FCLOSE( fp );
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}
}

INT	NES::IsStateFile( const char* fname, ROM* rom )
{
FILE*	fp = NULL;
FILEHDR2 header;

	if( !(fp = ::fopen( fname, "rb" )) )
		return	-1;

	if( ::fread( &header, sizeof(header), 1, fp ) != 1 ) {
		FCLOSE( fp );
		return	-1;
	}
	FCLOSE( fp );

	if( ::memcmp( header.ID, "VirtuaNES ST", sizeof(header.ID) ) == 0 ) {
		if( header.BlockVersion < 0x0100 )
			return	0;

		if( Config.emulator.bCrcCheck ) {
			if( header.BlockVersion >= 0x200 ) {
				if( rom->GetMapperNo() != 20 ) {
				// FDS�ȊO
					if( header.Ext0 != rom->GetPROM_CRC() ) {
						return	IDS_ERROR_ILLEGALSTATECRC;	// �Ⴄ�����
					}
				} else {
				// FDS
					if( header.Ext0 != rom->GetGameID() ||
					    header.Ext1 != (WORD)rom->GetMakerID() ||
					    header.Ext2 != (WORD)rom->GetDiskNo() )
						return	IDS_ERROR_ILLEGALSTATECRC;	// �Ⴄ�����
				}
			}
		}
		return	0;
	}
	return	-1;
}

BOOL	NES::LoadState( const char* fname )
{
FILE*	fp = NULL;
BOOL	bRet = FALSE;

	if( rom->IsNSF() )
		return	TRUE;

	try {
		if( !(fp = ::fopen( fname, "rb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, fname );
			throw	szErrorString;
		}

		bRet = ReadState( fp );

		FCLOSE( fp );
	} catch( CHAR* str ) {
		FCLOSE( fp );
		return	FALSE;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	bRet;
}

BOOL	NES::SaveState( const char* fname )
{
FILE*	fp = NULL;

	if( rom->IsNSF() )
		return	TRUE;

	try {
		if( !(fp = ::fopen( fname, "wb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, fname );
			throw	szErrorString;
		}

		WriteState( fp );

		FCLOSE( fp );
	} catch( CHAR* str ) {
		FCLOSE( fp );
		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	TRUE;
}

BOOL	NES::ReadState( FILE* fp )
{
	INT	i;
	BOOL	bHeader = FALSE;
	WORD	Version = 0;

	BLOCKHDR hdr;
	INT	type;

	while( TRUE ) {
		// Read File
		if( ::fread( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 )
			break;

		// File Header check
		if( !bHeader ) {
			LPFILEHDR	fh = (LPFILEHDR)&hdr;
			if( ::memcmp( fh->ID, "VirtuaNES ST", sizeof(fh->ID) ) == 0 ) {
				Version = fh->BlockVersion;
				if( Version == 0x0100 ) {
				// Ver0.24�܂�
					bHeader = TRUE;
					// �Â��z�̓��[�r�[���̓��[�h�o���܂���
					if( m_bMoviePlay ) {
						return	FALSE;
					}
					// �Â��z��FDS�̓��[�h�o���܂���
					if( rom->GetMapperNo() == 20 ) {
						// ���Ή��`���ł�
						throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
					}
				} else 
				if( Version == 0x0200 || Version == 0x0210 ) {
				// Ver0.30�ȍ~ Ver0.60�ȍ~
					FILEHDR2 hdr2;
					// �w�b�_���ǂݒ���
					if( ::fseek( fp, -sizeof(BLOCKHDR), SEEK_CUR ) ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}
					// Read File
					if( ::fread( &hdr2, sizeof(FILEHDR2), 1, fp ) != 1 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}

#if	0
					if( Config.emulator.bCrcCheck ) {
						// ���݃��[�h���̃^�C�g���ƈႤ�����`�F�b�N
						if( rom->GetMapperNo() != 20 ) {
						// FDS�ȊO
							if( hdr2.Ext0 != rom->GetPROM_CRC() ) {
								return	FALSE;	// �Ⴄ�����
							}
						} else {
						// FDS
							if( hdr2.Ext0 != rom->GetGameID() ||
							    hdr2.Ext1 != (WORD)rom->GetMakerID() ||
							    hdr2.Ext2 != (WORD)rom->GetDiskNo() )
								return	FALSE;	// �Ⴄ�����
						}
					}
#endif

					// ���[�r�[���̓t�@�C���|�C���^�ƃX�e�b�v����
					// �ύX���āC���[�r�[���L�^���[�h�ɕύX
					if( m_bMoviePlay || m_bMovieRec ) {
						// �B�蒼���\�H
						if( m_hedMovie.Control & 0x80 ) {
							if( hdr2.MovieOffset && hdr2.MovieStep ) {
								if( m_bMoviePlay ) {
								// �Đ���
									// �X�e�[�g�̃X�e�b�v�����L�^���i��ł���_��
									if( hdr2.MovieStep > m_hedMovie.MovieStep )
										return	FALSE;
								} else {
								// �L�^��
									// �X�e�[�g�̃X�e�b�v�������݂��i��ł���_��
									if( hdr2.MovieStep > m_MovieStep )
										return	FALSE;
								}

								m_bMoviePlay = FALSE;
								m_bMovieRec = TRUE;
								m_MovieStep = hdr2.MovieStep;
								m_hedMovie.RecordTimes++;	// �B�蒼����+1
								if( ::fseek( m_fpMovie, hdr2.MovieOffset, SEEK_SET ) ) {
									// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
									throw	CApp::GetErrorString( IDS_ERROR_READ );
								}
							} else {
								return	FALSE;
							}
						} else {
							return	FALSE;
						}
					}
				}
				bHeader = TRUE;
				continue;
			}
		}

		if( !bHeader ) {
			// ���Ή��`���ł�
			throw	CApp::GetErrorString( IDS_ERROR_UNSUPPORTFORMAT );
		}


		type = -1;
		if( ::memcmp( hdr.ID, "REG DATA", sizeof(hdr.ID) ) == 0 ) 
			type = 0;
		if( ::memcmp( hdr.ID, "RAM DATA", sizeof(hdr.ID) ) == 0 )
			type = 1;
		if( ::memcmp( hdr.ID, "MMU DATA", sizeof(hdr.ID) ) == 0 )
			type = 2;
		if( ::memcmp( hdr.ID, "MMC DATA", sizeof(hdr.ID) ) == 0 )
			type = 3;
		if( ::memcmp( hdr.ID, "CTR DATA", sizeof(hdr.ID) ) == 0 )
			type = 4;

		if( rom->GetMapperNo() == 20 ) {
			if( ::memcmp( hdr.ID, "DISKDATA", sizeof(hdr.ID) ) == 0 )
				type = 5;
		}

		if( type == -1 ) {
			break;
		}

		switch( type ) {
			case	0:
				// REGISTER STATE
				{
				if( hdr.BlockVersion < 0x0200 ) {
					REGSTAT_O	reg;
					if( ::fread( &reg, sizeof(REGSTAT_O), 1, fp ) != 1 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}

					// LOAD CPU STATE
					R6502	R;
					R.PC = reg.cpureg.cpu.PC;
					R.A  = reg.cpureg.cpu.A;
					R.X  = reg.cpureg.cpu.X;
					R.Y  = reg.cpureg.cpu.Y;
					R.S  = reg.cpureg.cpu.S;
					R.P  = reg.cpureg.cpu.P;
					R.INT_pending = reg.cpureg.cpu.I;
					cpu->SetContext( R );
					FrameIRQ = reg.cpureg.cpu.FrameIRQ;

					if( hdr.BlockVersion < 0x0110 ) {
						emul_cycles = 0;
						base_cycles = reg.cpureg.cpu.mod_cycles;
					} else if( hdr.BlockVersion == 0x0110 ) {
						FrameIRQ_cycles = reg.cpureg.cpu.mod_cycles;
						emul_cycles = reg.cpureg.cpu.emul_cycles;
						base_cycles = reg.cpureg.cpu.base_cycles;
					}

					// LOAD PPU STATE
					PPUREG[0] = reg.ppureg.ppu.reg0;
					PPUREG[1] = reg.ppureg.ppu.reg1;
					PPUREG[2] = reg.ppureg.ppu.reg2;
					PPUREG[3] = reg.ppureg.ppu.reg3;
					PPU7_Temp = reg.ppureg.ppu.reg7;
					loopy_t = reg.ppureg.ppu.loopy_t;
					loopy_v = reg.ppureg.ppu.loopy_v;
					loopy_x = reg.ppureg.ppu.loopy_x;
					PPU56Toggle = reg.ppureg.ppu.toggle56;
				} else {
					REGSTAT	reg;
					if( ::fread( &reg, sizeof(REGSTAT), 1, fp ) != 1 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}

					// LOAD CPU STATE
					R6502	R;
					R.PC = reg.cpureg.cpu.PC;
					R.A  = reg.cpureg.cpu.A;
					R.X  = reg.cpureg.cpu.X;
					R.Y  = reg.cpureg.cpu.Y;
					R.S  = reg.cpureg.cpu.S;
					R.P  = reg.cpureg.cpu.P;
					R.INT_pending = reg.cpureg.cpu.I;
					cpu->SetContext( R );

					FrameIRQ = reg.cpureg.cpu.FrameIRQ;
					bFrameIRQ_occur = (reg.cpureg.cpu.FrameIRQ_occur!=0)?TRUE:FALSE;
					FrameIRQ_cycles = reg.cpureg.cpu.FrameIRQ_cycles;
					emul_cycles = reg.cpureg.cpu.emul_cycles;
					base_cycles = reg.cpureg.cpu.base_cycles;

					cpu->SetDmaCycles( (INT)reg.cpureg.cpu.DMA_cycles );

					// LOAD PPU STATE
					PPUREG[0] = reg.ppureg.ppu.reg0;
					PPUREG[1] = reg.ppureg.ppu.reg1;
					PPUREG[2] = reg.ppureg.ppu.reg2;
					PPUREG[3] = reg.ppureg.ppu.reg3;
					PPU7_Temp = reg.ppureg.ppu.reg7;
					loopy_t = reg.ppureg.ppu.loopy_t;
					loopy_v = reg.ppureg.ppu.loopy_v;
					loopy_x = reg.ppureg.ppu.loopy_x;
					PPU56Toggle = reg.ppureg.ppu.toggle56;
				}

				// APU STATE
				// DMC�͎~�߂Ȃ��Ƃ܂��������N����
				for( i = 0x4010; i <= 0x4013; i++ ) {
					apu->Write( i, 0 );
				}
				}
				break;
			case	1:
				// RAM STATE
				{
				RAMSTAT	ram;
				if( ::fread( &ram, sizeof(RAMSTAT), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}
				::memcpy( RAM, ram.RAM, sizeof(ram.RAM) );
				::memcpy( BGPAL, ram.BGPAL, sizeof(ram.BGPAL) );
				::memcpy( SPPAL, ram.SPPAL, sizeof(ram.SPPAL) );
				::memcpy( SPRAM, ram.SPRAM, sizeof(ram.SPRAM) );
				if( rom->IsSAVERAM() ) {
					if( ::fread( WRAM, SAVERAM_SIZE, 1, fp ) != 1 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}
				}
				}
				break;
			case	2:
				// BANK STATE
				{
				MMUSTAT mmu;
				if( ::fread( &mmu, sizeof(MMUSTAT), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}
				if( hdr.BlockVersion == 0x100 ) {
				// ������ƑO�̃o�[�W����
					if( mmu.CPU_MEM_TYPE[3] == BANKTYPE_RAM
					 || mmu.CPU_MEM_TYPE[3] == BANKTYPE_DRAM ) {
						if( ::fread( CPU_MEM_BANK[3], 8*1024, 1, fp ) != 1 ) {
							// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
							throw	CApp::GetErrorString( IDS_ERROR_READ );
						}
					} else if( !rom->IsSAVERAM() ) {
						SetPROM_8K_Bank( 3, mmu.CPU_MEM_PAGE[3] );
					}
					// �o���N0�`3�ȊO���[�h
					for( i = 4; i < 8; i++ ) {
						CPU_MEM_TYPE[i] = mmu.CPU_MEM_TYPE[i];
						CPU_MEM_PAGE[i] = mmu.CPU_MEM_PAGE[i];
						if( CPU_MEM_TYPE[i] == BANKTYPE_ROM ) {
							SetPROM_8K_Bank( i, CPU_MEM_PAGE[i] );
						} else {
							if( ::fread( CPU_MEM_BANK[i], 8*1024, 1, fp ) != 1 ) {
								// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
								throw	CApp::GetErrorString( IDS_ERROR_READ );
							}
						}
					}
				} else if( hdr.BlockVersion == 0x200 ) {
				// �ŐV�o�[�W����
					// SRAM�������Ă��S�����[�h���Ȃ���
					for( i = 3; i < 8; i++ ) {
						CPU_MEM_TYPE[i] = mmu.CPU_MEM_TYPE[i];
						CPU_MEM_PAGE[i] = mmu.CPU_MEM_PAGE[i];
						if( CPU_MEM_TYPE[i] == BANKTYPE_ROM ) {
							SetPROM_8K_Bank( i, CPU_MEM_PAGE[i] );
						} else {
							if( ::fread( CPU_MEM_BANK[i], 8*1024, 1, fp ) != 1 ) {
								// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
								throw	CApp::GetErrorString( IDS_ERROR_READ );
							}
						}
					}
				}
				// VRAM
				if( ::fread( VRAM, 4*1024, 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}

				// CRAM
				for( i = 0; i < 8; i++ ) {
					if( mmu.CRAM_USED[i] != 0 ) {
						if( ::fread( &CRAM[0x1000*i], 4*1024, 1, fp ) != 1 ) {
							// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
							throw	CApp::GetErrorString( IDS_ERROR_READ );
						}
					}
				}
				// BANK
				for( i = 0; i < 12; i++ ) {
					if( mmu.PPU_MEM_TYPE[i] == BANKTYPE_VROM ) {
						SetVROM_1K_Bank( i, mmu.PPU_MEM_PAGE[i] );
					} else if( mmu.PPU_MEM_TYPE[i] == BANKTYPE_CRAM ) {
						SetCRAM_1K_Bank( i, mmu.PPU_MEM_PAGE[i] );
					} else if( mmu.PPU_MEM_TYPE[i] == BANKTYPE_VRAM ) {
						SetVRAM_1K_Bank( i, mmu.PPU_MEM_PAGE[i] );
					} else {
						throw	"Unknown bank types.";
					}
				}
				}
				break;
			case	3:
				// MMC STATE
				{
				MMCSTAT	mmc;
				if( ::fread( &mmc, sizeof(MMCSTAT), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}
				mapper->LoadState( mmc.mmcdata );
				}
				break;
			case	4:
				// CTR STATE
				{
				CTRSTAT	ctr;
				if( ::fread( &ctr, sizeof(CTRSTAT), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}

				pad->pad1bit = ctr.ctrreg.ctr.pad1bit;
				pad->pad2bit = ctr.ctrreg.ctr.pad2bit;
				pad->pad3bit = ctr.ctrreg.ctr.pad3bit;
				pad->pad4bit = ctr.ctrreg.ctr.pad4bit;
				pad->SetStrobe( (ctr.ctrreg.ctr.strobe!=0)?TRUE:FALSE );
				}
				break;

			// Disk Images
			// Ver0.30�ȍ~
			case	5:
				{
				DISKDATA ddata;
				DWORD	pos;
				BYTE	data;
				LONG	DiskSize = 16+65500*rom->GetDiskNo();
				LPBYTE	lpDisk  = rom->GetPROM();
				LPBYTE	lpWrite = rom->GetDISK();

				// ��������FLAG����
				::ZeroMemory( lpWrite, 16+65500*rom->GetDiskNo() );

				if( ::fread( &ddata, sizeof(DISKDATA), 1, fp ) != 1 ) {
					// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_READ );
				}

				for( i = 0; i < ddata.DifferentSize; i++ ) {
					if( ::fread( &pos, sizeof(DWORD), 1, fp ) != 1 ) {
						// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
						throw	CApp::GetErrorString( IDS_ERROR_READ );
					}
					data = (BYTE)(pos>>24);
					pos &= 0x00FFFFFF;
					if( pos >= 16 && pos < DiskSize ) {
						lpDisk[pos] = data;
						lpWrite[pos] = 0xFF;
					}
				}

				}
				break;
		}
	}

	return	TRUE;
}

void	NES::WriteState( FILE* fp )
{
	INT	i;

	// HEADER
	{
	FILEHDR2 hdr;

	::ZeroMemory( &hdr, sizeof(FILEHDR) );
	::memcpy( hdr.ID, "VirtuaNES ST", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0200;

	if( rom->GetMapperNo() != 20 ) {
		hdr.Ext0 = rom->GetPROM_CRC();
	} else {
		hdr.Ext0 = rom->GetGameID();
		hdr.Ext1 = (WORD)rom->GetMakerID();
		hdr.Ext2 = (WORD)rom->GetDiskNo();
	}

	// ���[�r�[�Đ���L�^���ł���΂��̈ʒu���L�^����
	if( m_bMoviePlay || m_bMovieRec ) {
		hdr.MovieStep   = m_MovieStep;
		hdr.MovieOffset = ::ftell( m_fpMovie );
	}

	// Write File
	if( ::fwrite( &hdr, sizeof(FILEHDR2), 1, fp ) != 1 )
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}

	BLOCKHDR hdr;

	// REGISTER STATE
	{
	REGSTAT	reg;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &reg, sizeof(REGSTAT) );

	// Create Header
	::memcpy( hdr.ID, "REG DATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0200;
	hdr.BlockSize    = sizeof(REGSTAT);

	// SAVE CPU STATE
	R6502	R;
	cpu->GetContext( R );

	reg.cpureg.cpu.PC = R.PC;
	reg.cpureg.cpu.A  = R.A;
	reg.cpureg.cpu.X  = R.X;
	reg.cpureg.cpu.Y  = R.Y;
	reg.cpureg.cpu.S  = R.S;
	reg.cpureg.cpu.P  = R.P;
	reg.cpureg.cpu.I  = R.INT_pending;

	reg.cpureg.cpu.FrameIRQ = FrameIRQ;
	reg.cpureg.cpu.FrameIRQ_occur = bFrameIRQ_occur?0xFF:0;
	reg.cpureg.cpu.FrameIRQ_cycles = FrameIRQ_cycles;

	reg.cpureg.cpu.DMA_cycles = (LONG)cpu->GetDmaCycles();
	reg.cpureg.cpu.emul_cycles = emul_cycles;
	reg.cpureg.cpu.base_cycles = base_cycles;

	// SAVE PPU STATE
	reg.ppureg.ppu.reg0 = PPUREG[0];
	reg.ppureg.ppu.reg1 = PPUREG[1];
	reg.ppureg.ppu.reg2 = PPUREG[2];
	reg.ppureg.ppu.reg3 = PPUREG[3];
	reg.ppureg.ppu.reg7 = PPU7_Temp;
	reg.ppureg.ppu.loopy_t  = loopy_t;
	reg.ppureg.ppu.loopy_v  = loopy_v;
	reg.ppureg.ppu.loopy_x  = loopy_x;
	reg.ppureg.ppu.toggle56 = PPU56Toggle;

	// Write File
	if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	if( ::fwrite( &reg, sizeof(REGSTAT), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	}

	// RAM STATE
	{
	RAMSTAT	ram;
	DWORD	size = 0;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &ram, sizeof(RAMSTAT) );

	// SAVE RAM STATE
	::memcpy( ram.RAM, RAM, sizeof(ram.RAM) );
	::memcpy( ram.BGPAL, BGPAL, sizeof(ram.BGPAL) );
	::memcpy( ram.SPPAL, SPPAL, sizeof(ram.SPPAL) );
	::memcpy( ram.SPRAM, SPRAM, sizeof(ram.SPRAM) );

	// S-RAM STATE(�g�p/���g�p�Ɋւ�炸���݂���΃Z�[�u����)
	if( rom->IsSAVERAM() ) {
		size = SAVERAM_SIZE;
	}

	// Create Header
	::memcpy( hdr.ID, "RAM DATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0100;
	hdr.BlockSize    = size+sizeof(RAMSTAT);

	// Write File
	if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	if( ::fwrite( &ram, sizeof(RAMSTAT), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	if( rom->IsSAVERAM() ) {
		if( ::fwrite( WRAM, SAVERAM_SIZE, 1, fp ) != 1 )
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}
	}

	// BANK STATE
	{
	MMUSTAT mmu;
	DWORD	size;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &mmu, sizeof(MMUSTAT) );

	size = 0;
	// SAVE CPU MEMORY BANK DATA
	// BANK0,1,2�̓o���N�Z�[�u�Ɋ֌W�Ȃ�
	// VirtuaNES0.30����
	// �o���N�R��SRAM�g�p�Ɋւ�炸�Z�[�u
	for( i = 3; i < 8; i++ ) {
		mmu.CPU_MEM_TYPE[i] = CPU_MEM_TYPE[i];
		mmu.CPU_MEM_PAGE[i] = CPU_MEM_PAGE[i];

		if( CPU_MEM_TYPE[i] == BANKTYPE_RAM
		 || CPU_MEM_TYPE[i] == BANKTYPE_DRAM ) {
			size += 8*1024;	// 8K BANK
		}
	}

	// SAVE VRAM MEMORY DATA
	for( i = 0; i < 12; i++ ) {
		mmu.PPU_MEM_TYPE[i] = PPU_MEM_TYPE[i];
		mmu.PPU_MEM_PAGE[i] = PPU_MEM_PAGE[i];
	}
	size += 4*1024;	// 1K BANK x 4 (VRAM)

	for( i = 0; i < 8; i++ ) {
		mmu.CRAM_USED[i] = CRAM_USED[i];
		if( CRAM_USED[i] != 0 ) {
			size += 4*1024;	// 4K BANK
		}
	}

	// Create Header
	::memcpy( hdr.ID, "MMU DATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0200;
	hdr.BlockSize    = size+sizeof(MMUSTAT);

	// Write File
	if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	if( ::fwrite( &mmu, sizeof(MMUSTAT), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}

	// WRITE CPU RAM MEMORY BANK
	for( i = 3; i < 8; i++ ) {
		if( mmu.CPU_MEM_TYPE[i] != BANKTYPE_ROM ) {
			if( ::fwrite( CPU_MEM_BANK[i], 8*1024, 1, fp ) != 1 ) {
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}
	}
	// WRITE VRAM MEMORY(���4K�����ׂď�������)
	if( ::fwrite( VRAM, 4*1024, 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}

	// WRITE CRAM MEMORY
	for( i = 0; i < 8; i++ ) {
		if( CRAM_USED[i] != 0 ) {
			if( ::fwrite( &CRAM[0x1000*i], 4*1024, 1, fp ) != 1 ) {
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}
	}
	}

	// MMC STATE
	{
	MMCSTAT	mmc;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &mmc, sizeof(MMCSTAT) );

	// Create Header
	::memcpy( hdr.ID, "MMC DATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0100;
	hdr.BlockSize    = sizeof(MMCSTAT);

	if( mapper->IsStateSave() ) {
		mapper->SaveState( mmc.mmcdata );
		// Write File
		if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}
		if( ::fwrite( &mmc, sizeof(MMCSTAT), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}
	}
	}

	// CONTROLLER STATE
	{
	CTRSTAT	ctr;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &ctr, sizeof(CTRSTAT) );

	// Create Header
	::memcpy( hdr.ID, "CTR DATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0100;
	hdr.BlockSize    = sizeof(CTRSTAT);

	ctr.ctrreg.ctr.pad1bit = pad->pad1bit;
	ctr.ctrreg.ctr.pad2bit = pad->pad2bit;
	ctr.ctrreg.ctr.pad3bit = pad->pad3bit;
	ctr.ctrreg.ctr.pad4bit = pad->pad4bit;
	ctr.ctrreg.ctr.strobe  = pad->GetStrobe()?0xFF:0;

	if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}

	if( ::fwrite( &ctr, sizeof(CTRSTAT), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	}

	// DISKIMAGE STATE
	if( rom->GetMapperNo() == 20 )
	{
	DISKDATA dsk;
	LPBYTE	lpDisk  = rom->GetPROM();
	LPBYTE	lpWrite = rom->GetDISK();
	LONG	DiskSize = 16+65500*rom->GetDiskNo();
	DWORD	data;

	::ZeroMemory( &hdr, sizeof(BLOCKHDR) );
	::ZeroMemory( &dsk, sizeof(DISKDATA) );

	// ���ᐔ���J�E���g
	for( i = 16; i < DiskSize; i++ ) {
		if( lpWrite[i] )
			dsk.DifferentSize++;
	}

	::memcpy( hdr.ID, "DISKDATA", sizeof(hdr.ID) );
	hdr.BlockVersion = 0x0210;
	hdr.BlockSize    = 0;

	// Write File
	if( ::fwrite( &hdr, sizeof(BLOCKHDR), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}
	// Write File
	if( ::fwrite( &dsk, sizeof(DISKDATA), 1, fp ) != 1 ) {
		// �t�@�C���̏������݂Ɏ��s���܂���
		throw	CApp::GetErrorString( IDS_ERROR_WRITE );
	}

	for( i = 16; i < DiskSize; i++ ) {
		if( lpWrite[i] ) {
			data = i & 0x00FFFFFF;
			data |= ((DWORD)lpDisk[i]&0xFF)<<24;

			// Write File
			if( ::fwrite( &data, sizeof(DWORD), 1, fp ) != 1 ) {
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}
	}
	}
}

INT	NES::GetDiskNo()
{
	return	rom->GetDiskNo();
}

void	NES::SoundSetup()
{
	apu->SoundSetup();
}

void	NES::Command( NESCOMMAND cmd )
{
	CommandParam( cmd, 0 );
}

BOOL	NES::CommandParam( NESCOMMAND cmd, INT param )
{
	switch( cmd ) {
		case	NESCMD_NONE:
			break;
		case	NESCMD_DISK_THROTTLE_ON:
			if( Config.emulator.bDiskThrottle ) {
				m_bDiskThrottle = TRUE;
			}
			break;
		case	NESCMD_DISK_THROTTLE_OFF:
			m_bDiskThrottle = FALSE;
			break;
		case	NESCMD_DISK_EJECT:
			mapper->ExCmdWrite( Mapper::EXCMDWR_DISKEJECT, 0 );
			m_CommandRequest = (INT)cmd;
			break;
		case	NESCMD_DISK_0A:
			if( rom->GetDiskNo() > 0 ) {
				mapper->ExCmdWrite( Mapper::EXCMDWR_DISKINSERT, 0 );
				m_CommandRequest = (INT)cmd;
			}
			break;
		case	NESCMD_DISK_0B:
			if( rom->GetDiskNo() > 1 ) {
				mapper->ExCmdWrite( Mapper::EXCMDWR_DISKINSERT, 1 );
				m_CommandRequest = (INT)cmd;
			}
			break;
		case	NESCMD_DISK_1A:
			if( rom->GetDiskNo() > 2 ) {
				mapper->ExCmdWrite( Mapper::EXCMDWR_DISKINSERT, 2 );
				m_CommandRequest = (INT)cmd;
			}
			break;
		case	NESCMD_DISK_1B:
			if( rom->GetDiskNo() > 3 ) {
				mapper->ExCmdWrite( Mapper::EXCMDWR_DISKINSERT, 3 );
				m_CommandRequest = (INT)cmd;
			}
			break;

		case	NESCMD_HWRESET:
			Reset();
			m_CommandRequest = (INT)cmd;
			break;
		case	NESCMD_SWRESET:
			SoftReset();
			m_CommandRequest = (INT)cmd;
			break;

		case	NESCMD_EXCONTROLLER:
			pad->SetExController( param&0xFF );
			m_CommandRequest = 0x0100|(param&0xFF);
			break;

		case	NESCMD_SOUND_MUTE:
			return	apu->SetChannelMute( (BOOL)param ); // ���^�[���l�͕ύX��̃~���[�g���
	}

	return	TRUE;
}

BOOL	NES::Snapshot()
{
FILE*	fp = NULL;

	try {
#if	1
		SYSTEMTIME	now;
		::GetLocalTime( &now );

		CHAR	name[_MAX_PATH];
		sprintf( name, "%s %04d%02d%02d%02d%02d%02d%01d.bmp", rom->GetRomName(),
			now.wYear, now.wMonth, now.wDay, now.wHour, now.wMinute, now.wSecond, now.wMilliseconds/100 );
#else
		CHAR	name[_MAX_PATH];
		sprintf( name, "%s%04d.bmp", rom->GetRomName(), m_nSnapNo );
		if( ++m_nSnapNo > 9999 )
			m_nSnapNo = 9999;
#endif
		string	tempstr;
		if( Config.path.bSnapshotPath ) {
			CreateDirectory( Config.path.szSnapshotPath, NULL );
			tempstr = CPathlib::MakePath( Config.path.szSnapshotPath, name );
		} else {
			tempstr = CPathlib::MakePath( rom->GetRomPath(), name );
		}


		RECT rcframe;
		GetClientRect(parent->m_hWnd, &rcframe);
		int width = rcframe.right - rcframe.left;
		int height = rcframe.bottom - rcframe.top;
		HDC m_dc = GetDC(parent->m_hWnd);
		HDC m_memdc = CreateCompatibleDC(m_dc);
		HBITMAP m_bmp = CreateCompatibleBitmap(m_dc, width, height);
		HBITMAP oldbmp = (HBITMAP)SelectObject(m_memdc, m_bmp);
		BitBlt(m_memdc, 0, 0, width, height, m_dc, 0, 0, SRCCOPY);
		
		//д��λͼ�ļ�
		SaveBitmapToFile(m_bmp, (char *)tempstr.c_str());

		SelectObject(m_memdc, oldbmp);
		ReleaseDC(parent->m_hWnd, m_dc);
		DeleteDC(m_memdc);


		/*if( !(fp = ::fopen( tempstr.c_str(), "wb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, tempstr.c_str() );
			throw	szErrorString;
		}
		


		LPBYTE	lpScn = ppu->GetScreenPtr();

		BITMAPFILEHEADER bfh;
		BITMAPINFOHEADER bih;
		RGBQUAD		 rgb[256];

		::ZeroMemory( &bfh, sizeof(bfh) );
		::ZeroMemory( &bih, sizeof(bih) );
		::ZeroMemory( rgb, sizeof(rgb) );

		bfh.bfType = 0x4D42;	// 'BM'
		bfh.bfOffBits = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+sizeof(RGBQUAD)*256;
		bfh.bfSize = bfh.bfOffBits+256*240;

		bih.biSize          = sizeof(bih);
		bih.biWidth         = 256;
		bih.biHeight        = 240;
		bih.biPlanes        = 1;
		bih.biBitCount      = 8;
		bih.biCompression   = BI_RGB;
		bih.biSizeImage     = 0;
		bih.biXPelsPerMeter = 0;
		bih.biYPelsPerMeter = 0;
		bih.biClrUsed       = 256;
		bih.biClrImportant  = 0;

		DirectDraw.GetPaletteData( rgb );

		if( ::fwrite( &bfh, sizeof(bfh), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}
		if( ::fwrite( &bih, sizeof(bih), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}
		if( ::fwrite( &rgb, sizeof(rgb), 1, fp ) != 1 ) {
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}

		lpScn += 8;
		for( INT i = 239; i >= 0; i-- ) {
			if( ::fwrite( &lpScn[(256+16)*i], 256, 1, fp ) != 1 ) {
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}

		FCLOSE( fp );*/

	} catch( CHAR* str ) {
		FCLOSE( fp );
		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( fp );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	TRUE;
}

INT	NES::IsMovieFile( const char* fname, ROM* rom )
{
FILE*	fp = NULL;
MOVIEFILEHDR	header;

	if( !(fp = ::fopen( fname, "rb" )) )
		return	-1;

	if( ::fread( &header, sizeof(header), 1, fp ) != 1 ) {
		FCLOSE( fp );
		return	-1;
	}
	FCLOSE( fp );

	if( ::memcmp( header.ID, "VirtuaNES MV", sizeof(header.ID) ) == 0 ) {
		if( header.BlockVersion < 0x0300 ) {
			return	IDS_ERROR_ILLEGALMOVIEOLD;
		} else 
		if( header.BlockVersion >= 0x0300 ) {
			if( rom->GetMapperNo() != 20 ) {
			// FDS�ȊO
				if( header.Ext0 != rom->GetPROM_CRC() ) {
					return	IDS_ERROR_ILLEGALMOVIECRC;	// �Ⴄ�����
				}
			} else {
			// FDS
				if( header.Ext0 != rom->GetGameID() ||
				    header.Ext1 != (WORD)rom->GetMakerID() ||
				    header.Ext2 != (WORD)rom->GetDiskNo() )
					return	IDS_ERROR_ILLEGALMOVIECRC;	// �Ⴄ�����
			}

			if( header.RecordVersion != VIRTUANES_VERSION ) {
				return	IDS_ERROR_ILLEGALMOVIEVER;
			}

			return	0;
		}
	}

	return	-1;
}

BOOL	NES::MoviePlay( const char* fname )
{
	if( rom->IsNSF() )
		return	FALSE;

	if( IsMoviePlay() || IsMovieRec() ) {
		MovieStop();
	}


	try {
		if( !(m_fpMovie = ::fopen( fname, "rb+" )) ) {
			// �t�@�C�������ł�
			return	FALSE;
		}

		// �ǂݍ���
		if( ::fread( &m_hedMovie, sizeof(m_hedMovie), 1, m_fpMovie ) != 1 ) {
			// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_READ );
		}

		if( ::memcmp( m_hedMovie.ID, "VirtuaNES MV", sizeof(m_hedMovie.ID) ) == 0 ) {
			m_MovieVersion = m_hedMovie.BlockVersion;

			if( m_hedMovie.BlockVersion == 0x0300 ) {
				if( m_hedMovie.CRC != 0 ) {
					if( CRC::Crc( sizeof(m_hedMovie)-sizeof(DWORD), (LPBYTE)&m_hedMovie ) != m_hedMovie.CRC ) {
						FCLOSE( m_fpMovie );
						return	FALSE;	// �Ⴄ�����
					}
				}
				// �������`
			} else {
				// �搶�I�Â��̂Ń_�������B
				FCLOSE( m_fpMovie );
				return	FALSE;
			}
		}

		// �Q�[���ŗL�I�v�V����
		m_saveRenderMethod = (INT)GetRenderMethod();
		m_saveIrqType      = GetIrqType();
		m_saveFrameIRQ     = GetFrameIRQmode();
		m_saveVideoMode    = GetVideoMode();
		SetRenderMethod( (RENDERMETHOD)m_hedMovie.RenderMethod );
		SetIrqType( (INT)m_hedMovie.IRQtype );
		SetFrameIRQmode( (m_hedMovie.FrameIRQ!=0)?TRUE:FALSE );
		SetVideoMode( (m_hedMovie.VideoMode!=0)?TRUE:FALSE );

		LONG	MovieOffset;
		m_MovieControl   = m_hedMovie.Control;
		m_MovieStepTotal = m_hedMovie.MovieStep;
		MovieOffset      = m_hedMovie.MovieOffset;

		// �X�e�[�g�ǂݍ���
		ReadState( m_fpMovie );

		if( ::fseek( m_fpMovie, MovieOffset, SEEK_SET ) ) {
			// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_READ );
		}

		// ���[�r�[���L�^����Ă��Ȃ��H
		if( m_MovieStepTotal == 0 ) {
			MovieStop();
			return	FALSE;
		}

		m_bMoviePlay = TRUE;
		m_MovieStep = 0;
	} catch( CHAR* str ) {
		FCLOSE( m_fpMovie );
		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( m_fpMovie );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	TRUE;
}

BOOL	NES::MovieRec( const char* fname )
{
	if( rom->IsNSF() )
		return	FALSE;

	if( IsMoviePlay() || IsMovieRec() ) {
		MovieStop();
	}


	try {
		if( !(m_fpMovie = ::fopen( fname, "wb" )) ) {
			// xxx �t�@�C�����J���܂���
			LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
			sprintf( szErrorString, szErrStr, fname );
			throw	szErrorString;
		}

		::ZeroMemory( &m_hedMovie, sizeof(m_hedMovie) );
		::memcpy( m_hedMovie.ID, "VirtuaNES MV", sizeof(m_hedMovie.ID) );
		m_hedMovie.BlockVersion = 0x0300;
		m_hedMovie.RecordVersion = VIRTUANES_VERSION;

		m_hedMovie.StateStOffset = sizeof(m_hedMovie);

		m_hedMovie.Control |= Config.movie.bUsePlayer[0]?0x01:0x00;
		m_hedMovie.Control |= Config.movie.bUsePlayer[1]?0x02:0x00;
		m_hedMovie.Control |= Config.movie.bUsePlayer[2]?0x04:0x00;
		m_hedMovie.Control |= Config.movie.bUsePlayer[3]?0x08:0x00;
		m_hedMovie.Control |= Config.movie.bRerecord?0x80:0x00;
		m_MovieControl = m_hedMovie.Control;

		// �Q�[���ŗL�I�v�V����
		m_hedMovie.RenderMethod = (BYTE)GetRenderMethod();
		m_hedMovie.IRQtype      = (BYTE)GetIrqType();
		m_hedMovie.FrameIRQ     = GetFrameIRQmode()?0xFF:0;
		m_hedMovie.VideoMode    = GetVideoMode()?0xFF:0;

		// CRC,ID�l����������(�듮��h�~�p)
		if( rom->GetMapperNo() != 20 ) {
		// FDS�ȊO
			m_hedMovie.Ext0 = rom->GetPROM_CRC();
		} else {
		// FDS
			m_hedMovie.Ext0 =       rom->GetGameID();
			m_hedMovie.Ext1 = (WORD)rom->GetMakerID();
			m_hedMovie.Ext2 = (WORD)rom->GetDiskNo();
		}

		// �_�~�[��������
		if( ::fwrite( &m_hedMovie, sizeof(m_hedMovie), 1, m_fpMovie ) != 1 ) {
			FCLOSE( m_fpMovie );
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}

		if( Config.movie.bResetRec ) {
			Reset();	// �n�[�h�E�F�A���Z�b�g����̋L�^�J�n
		}

		// �X�e�[�g��������
		WriteState( m_fpMovie );

		m_hedMovie.MovieOffset = ::ftell( m_fpMovie );
		m_bMovieRec = TRUE;
		m_MovieStep = m_MovieStepTotal = 0;
		m_MovieVersion = 0x0300;
	} catch( CHAR* str ) {
		FCLOSE( m_fpMovie );
		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( m_fpMovie );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	TRUE;
}

BOOL	NES::MovieRecAppend( const char* fname )
{
	if( rom->IsNSF() )
		return	FALSE;

	// �L�^���͈Ӗ���������
	if( IsMovieRec() )
		return	FALSE;

	if( IsMoviePlay() ) {
		MovieStop();
	}


	try {
		if( !(m_fpMovie = ::fopen( fname, "rb" )) ) {
			// �t�@�C���������Ƃ�
			if( !(m_fpMovie = ::fopen( fname, "wb" )) ) {
				// xxx �t�@�C�����J���܂���
				LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
				sprintf( szErrorString, szErrStr, fname );
				throw	szErrorString;
			}

			::ZeroMemory( &m_hedMovie, sizeof(m_hedMovie) );
			::memcpy( m_hedMovie.ID, "VirtuaNES MV", sizeof(m_hedMovie.ID) );
			m_hedMovie.BlockVersion = 0x0300;
			m_hedMovie.RecordVersion = VIRTUANES_VERSION;
			m_hedMovie.StateStOffset = sizeof(m_hedMovie);

			m_hedMovie.Control |= Config.movie.bUsePlayer[0]?0x01:0x00;
			m_hedMovie.Control |= Config.movie.bUsePlayer[1]?0x02:0x00;
			m_hedMovie.Control |= Config.movie.bUsePlayer[2]?0x04:0x00;
			m_hedMovie.Control |= Config.movie.bUsePlayer[3]?0x08:0x00;
			m_hedMovie.Control |= Config.movie.bRerecord?0x80:0x00;
//			m_hedMovie.Control |= Config.movie.bResetRec?0x40:0x00;
			m_MovieControl = m_hedMovie.Control;

			// �Q�[���ŗL�I�v�V����
			m_hedMovie.RenderMethod = (BYTE)GetRenderMethod();
			m_hedMovie.IRQtype      = (BYTE)GetIrqType();
			m_hedMovie.FrameIRQ     = GetFrameIRQmode()?0xFF:0;
			m_hedMovie.VideoMode    = GetVideoMode()?0xFF:0;

			// �_�~�[��������
			if( ::fwrite( &m_hedMovie, sizeof(m_hedMovie), 1, m_fpMovie ) != 1 ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}

			if( Config.movie.bResetRec ) {
				Reset();	// �n�[�h�E�F�A���Z�b�g����̋L�^�J�n
			}
			// �X�e�[�g��������
			WriteState( m_fpMovie );

			m_hedMovie.MovieOffset = ::ftell( m_fpMovie );
			m_MovieStep = m_MovieStepTotal = 0;
			m_MovieVersion = 0x0300;
		} else {
			if( !(m_fpMovie = ::fopen( fname, "rb+" )) ) {
				// xxx �t�@�C�����J���܂���
				LPCSTR	szErrStr = CApp::GetErrorString( IDS_ERROR_OPEN );
				sprintf( szErrorString, szErrStr, fname );
				throw	szErrorString;
			}
			// �ǂݍ���
			if( ::fseek( m_fpMovie, 0, SEEK_SET ) ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}
			if( ::fread( &m_hedMovie, sizeof(m_hedMovie), 1, m_fpMovie ) != 1 ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}

			if( ::memcmp( m_hedMovie.ID, "VirtuaNES MV", sizeof(m_hedMovie.ID) ) != 0 ) {
				FCLOSE( m_fpMovie );
				return	FALSE;
			}
			// �Â��o�[�W�����͎̂�
			if( m_hedMovie.BlockVersion < 0x0300 ) {
				FCLOSE( m_fpMovie );
				return	FALSE;
			}

			m_MovieControl = m_hedMovie.Control;
			m_MovieStep = m_MovieStepTotal = m_hedMovie.MovieStep;
			m_MovieVersion = 0x0300;

			if( ::fseek( m_fpMovie, m_hedMovie.StateEdOffset, SEEK_SET ) ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}
			if( !ReadState( m_fpMovie ) ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}
			if( ::fseek( m_fpMovie, m_hedMovie.StateEdOffset, SEEK_SET ) ) {
				FCLOSE( m_fpMovie );
				// �t�@�C���̓ǂݍ��݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_READ );
			}
		}
		m_bMovieRec = TRUE;
	} catch( CHAR* str ) {
		FCLOSE( m_fpMovie );
		throw	str;
#ifndef	_DEBUG
	} catch(...) {
		FCLOSE( m_fpMovie );
		// �s���ȃG���[���������܂���
		throw	CApp::GetErrorString( IDS_ERROR_UNKNOWN );
#endif
	}

	return	TRUE;
}

BOOL	NES::MovieStop()
{
	if( !m_fpMovie && !(m_bMoviePlay||m_bMovieRec) )
		return	FALSE;


	DirectDraw.SetMessageString( "Movie stop." );

	if( m_bMovieRec ) {
		m_hedMovie.MovieStep = m_MovieStep;
		m_hedMovie.StateEdOffset = ::ftell( m_fpMovie );
		WriteState( m_fpMovie );

//		// �B�蒼���֎~�̏ꍇ�͒ǋL�s�\
//		if( m_MovieControl & 0x80 ) {
//		} else {
//			m_hedMovie.StateEdOffset = 0;
//		}
		if( ::fseek( m_fpMovie, 0, SEEK_SET ) ) {
			FCLOSE( m_fpMovie );
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}

		// CRC ��������
		m_hedMovie.CRC = CRC::Crc( sizeof(m_hedMovie)-sizeof(DWORD), (LPBYTE)&m_hedMovie );

		// �ŏI�I�ȃw�b�_��������
		if( ::fwrite( &m_hedMovie, sizeof(m_hedMovie), 1, m_fpMovie ) != 1 ) {
			FCLOSE( m_fpMovie );
			// �t�@�C���̏������݂Ɏ��s���܂���
			throw	CApp::GetErrorString( IDS_ERROR_WRITE );
		}

		FCLOSE( m_fpMovie );
		m_bMovieRec = FALSE;
	}

	if( m_bMoviePlay ) {
		FCLOSE( m_fpMovie );
		m_bMoviePlay = FALSE;

		// �Q�[���ŗL�I�v�V���������ɖ߂�
		SetRenderMethod( (RENDERMETHOD)m_saveRenderMethod );
		SetIrqType     ( m_saveIrqType );
		SetFrameIRQmode( m_saveFrameIRQ );
		SetVideoMode   ( m_saveVideoMode );
	}

	return	TRUE;
}

void	NES::GetMovieInfo( WORD& wRecVersion, WORD& wVersion, DWORD& dwRecordFrames, DWORD& dwRecordTimes )
{
	wRecVersion    = m_hedMovie.RecordVersion;
	wVersion       = m_hedMovie.BlockVersion;
	dwRecordFrames = m_hedMovie.MovieStep;
	dwRecordTimes  = m_hedMovie.RecordTimes;
}

// ���t���[���Ăяo��
void	NES::Movie()
{
	if( !m_fpMovie && !(m_bMoviePlay||m_bMovieRec) ) {
		m_CommandRequest = 0;	// �R������Ȃ��Ǝ���
		return;
	}

	INT	exctr = pad->GetExController();

	BYTE	Data;
	WORD	wData;
	DWORD	dwData;

	if( m_bMovieRec ) {
		// �ŏ�����g�����۰ׂ��ݒ肳��Ă����ꍇ
		if( m_MovieStep == 0 ) {
			if( exctr == PAD::EXCONTROLLER_ZAPPER
			 || exctr == PAD::EXCONTROLLER_PADDLE
			 || exctr == PAD::EXCONTROLLER_CRAZYCLIMBER
			 || exctr == PAD::EXCONTROLLER_TOPRIDER
			 || exctr == PAD::EXCONTROLLER_SPACESHADOWGUN ) {
				// �R�}���hID
				Data = 0xF0;
				// ��������
				if( ::fwrite( &Data, sizeof(Data), 1, m_fpMovie ) != 1 ) {
					MovieStop();
					// �t�@�C���̏������݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_WRITE );
				}
				// ���
				wData = (WORD)(0x0100|(pad->GetExController()&0x0FF));
				// ��������
				if( ::fwrite( &wData, sizeof(wData), 1, m_fpMovie ) != 1 ) {
					MovieStop();
					// �t�@�C���̏������݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_WRITE );
				}
			}
		}

		if( m_CommandRequest ) {
			// �R�}���hID
			Data = 0xF0;
			// ��������
			if( ::fwrite( &Data, sizeof(Data), 1, m_fpMovie ) != 1 ) {
				MovieStop();
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
			// �R�}���h
			wData = (WORD)m_CommandRequest;
			// ��������
			if( ::fwrite( &wData, sizeof(wData), 1, m_fpMovie ) != 1 ) {
				MovieStop();
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}
		m_CommandRequest = 0;

		// �g�����۰�
		if( exctr == PAD::EXCONTROLLER_ZAPPER
		 || exctr == PAD::EXCONTROLLER_PADDLE
		 || exctr == PAD::EXCONTROLLER_CRAZYCLIMBER
		 || exctr == PAD::EXCONTROLLER_TOPRIDER
		 || exctr == PAD::EXCONTROLLER_SPACESHADOWGUN ) {
			// �g���R���g���[���f�[�^ID
			Data = 0xF3;
			// ��������
			if( ::fwrite( &Data, sizeof(Data), 1, m_fpMovie ) != 1 ) {
				MovieStop();
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
			// �f�[�^
			dwData = pad->GetSyncExData();

			// ��������
			if( ::fwrite( &dwData, sizeof(dwData), 1, m_fpMovie ) != 1 ) {
				MovieStop();
				// �t�@�C���̏������݂Ɏ��s���܂���
				throw	CApp::GetErrorString( IDS_ERROR_WRITE );
			}
		}

		dwData = pad->GetSyncData();
		for( INT i = 0; i < 4; i++ ) {
			Data = (BYTE)(dwData>>(i*8));
			if( m_MovieControl & (1<<i) ) {
				// ��������
				if( ::fwrite( &Data, sizeof(Data), 1, m_fpMovie ) != 1 ) {
					MovieStop();
					// �t�@�C���̏������݂Ɏ��s���܂���
					throw	CApp::GetErrorString( IDS_ERROR_WRITE );
				}
			}
		}

		m_MovieStep++;
	}

	if( m_bMoviePlay ) {
		DWORD	dwPadData = 0;
		INT	num = 0;
		BYTE	PadBuf[4];

		PadBuf[0] = PadBuf[1] = PadBuf[2] = PadBuf[3] = 0;

		// ���[�r�[�Đ��I���H
		if( m_MovieStep >= m_MovieStepTotal ) {
			if( !Config.movie.bLoopPlay ) {
				MovieStop();
				return;
			} else {
				// ��U�Đ�������Ȃ����Ď��ɂ���
				m_bMoviePlay = FALSE;
				m_MovieStep = 0;
				::fseek( m_fpMovie, m_hedMovie.StateStOffset, SEEK_SET );
				// �X�e�[�g�ǂݍ���
				ReadState( m_fpMovie );
				::fseek( m_fpMovie, m_hedMovie.MovieOffset, SEEK_SET );
				// �Đ������Ď��ɂ���
				m_bMoviePlay = TRUE;
			}
		}

		do {
			// �ǂݍ���
			if( ::fread( &Data, sizeof(Data), 1, m_fpMovie ) != 1 ) {
				// �I���H
				MovieStop();
				return;
			}

			// �R�}���h�H
			if( (Data & 0xF0) == 0xF0 ) {
				if( Data == 0xF0 ) {
					// �ǂݍ���
					if( ::fread( &wData, sizeof(wData), 1, m_fpMovie ) != 1 ) {
						// �I���H
						MovieStop();
						return;
					}
					if( wData < 0x0100 ) {
						Command( (NESCOMMAND)((INT)wData) );
					} else {
						// �g�����۰�
						CommandParam( NESCMD_EXCONTROLLER, ((INT)wData) & 0x00FF );
					}
				} else 
				if( Data == 0xF3 ) {
					// �ǂݍ���
					if( ::fread( &dwData, sizeof(dwData), 1, m_fpMovie ) != 1 ) {
						// �I���H
						MovieStop();
						return;
					}
					pad->SetSyncExData( dwData );
				} else {
					// �f�[�^�Ԃ����Ă�H�I������
					MovieStop();
					return;
				}
			} else {
				// ���g�p�v���C���[��������΂�
				while( !(m_MovieControl & (1<<num)) && (num < 4) ) {
					PadBuf[num] = 0;
					num++;
				}
				PadBuf[num] = Data;
				num++;
				// ���g�p�v���C���[��������΂�
				while( !(m_MovieControl & (1<<num)) && (num < 4) ) {
					PadBuf[num] = 0;
					num++;
				}
			}
		} while( num < 4 );

		dwData = (((DWORD)PadBuf[3])<<24)|(((DWORD)PadBuf[2])<<16)|(((DWORD)PadBuf[1])<<8)|((DWORD)PadBuf[0]);
		pad->SetSyncData( dwData );

		// �J�E���^���₷
		m_MovieStep++;
	}

	m_CommandRequest = 0;
}

// For Cheat
void	NES::CheatInitial()
{
	m_CheatCode.clear();
}

BOOL	NES::IsCheatCodeAdd()
{
	BOOL bRet = m_bCheatCodeAdd;
	m_bCheatCodeAdd = FALSE;

	return	bRet;
}

INT	NES::GetCheatCodeNum()
{
	return	m_CheatCode.size();
}

BOOL	NES::GetCheatCode( INT no, CHEATCODE& code )
{
	if( m_CheatCode.size()-1 < no )
		return	FALSE;

	code = m_CheatCode[no];
	return	TRUE;
}

void	NES::SetCheatCodeFlag( INT no, BOOL bEnable )
{
	if( m_CheatCode.size()-1 < no )
		return;

	if( bEnable ) {
		m_CheatCode[no].enable |= CHEAT_ENABLE;
	} else {
		m_CheatCode[no].enable &= ~CHEAT_ENABLE;
	}
}

void	NES::SetCheatCodeAllFlag( BOOL bEnable, BOOL bKey )
{
	for( INT i = 0; i < m_CheatCode.size(); i++ ) {
		if( !bKey ) {
			if( bEnable ) {
				m_CheatCode[i].enable |= CHEAT_ENABLE;
			} else {
				m_CheatCode[i].enable &= ~CHEAT_ENABLE;
			}
		} else if( !(m_CheatCode[i].enable&CHEAT_KEYDISABLE) ) {
			if( bEnable ) {
				m_CheatCode[i].enable |= CHEAT_ENABLE;
			} else {
				m_CheatCode[i].enable &= ~CHEAT_ENABLE;
			}
		}
	}
}

void	NES::ReplaceCheatCode( INT no, CHEATCODE code )
{
	if( m_CheatCode.size()-1 < no )
		return;

	m_CheatCode[no] = code;
}

void	NES::AddCheatCode( CHEATCODE code )
{
	m_CheatCode.push_back( code );
	m_bCheatCodeAdd = TRUE;
}

void	NES::DelCheatCode( INT no )
{
	if( m_CheatCode.size()-1 < no )
		return;

	m_CheatCode.erase( &m_CheatCode[no] );
}

DWORD	NES::CheatRead( INT length, WORD addr )
{
	DWORD	data = 0;
	for( INT i = 0; i <= length; i++ ) {
		data |= (DWORD)Read( addr+i )*(1<<(i*8));
	}

	return	data;
}

void	NES::CheatWrite( INT length, WORD addr, DWORD data )
{
	for( INT i = 0; i <= length; i++ ) {
		Write( (WORD)(addr+i), data&0xFF );
		data >>= 8;
	}
}

void	NES::CheatCodeProcess()
{
	for( vector<CHEATCODE>::iterator it = m_CheatCode.begin(); it != m_CheatCode.end(); it++ ) {
		if( !(it->enable & CHEAT_ENABLE) )
			continue;

		switch( it->type ) {
			case	CHEAT_TYPE_ALWAYS:
				CheatWrite( it->length, it->address, it->data );
				break;
			case	CHEAT_TYPE_ONCE:
				CheatWrite( it->length, it->address, it->data );
				it->enable = 0;
				break;
			case	CHEAT_TYPE_GREATER:
				if( CheatRead( it->length, it->address ) > it->data ) {
					CheatWrite( it->length, it->address, it->data );
				}
				break;
			case	CHEAT_TYPE_LESS:
				if( CheatRead( it->length, it->address ) < it->data ) {
					CheatWrite( it->length, it->address, it->data );
				}
				break;
		}
	}
}

void	NES::GenieInitial()
{
	m_bCheatCodeAdd = FALSE;
	m_GenieCode.clear();
}

void	NES::GenieLoad( char* fname )
{
FILE*	fp = NULL;

	CHAR	buf[256];
	GENIECODE	code;
	BYTE	codetmp[9];
	INT	no;

	if( (fp = ::fopen( fname, "r" )) ) {
		m_GenieCode.clear();

		while( ::fgets( buf, sizeof(buf), fp ) ) {
			if( buf[0] == ';' )
				continue;
			if( buf[0] == 0x0D || buf[0] == 0x0A )
				continue;

			if( ::strlen( buf ) < 6 )
				continue;

			code.address = 0;
			code.data = 0;
			code.cmp = 0;

			for( no = 0; isalpha(buf[no]) && no < 8; no++ ) {
				switch( buf[no] ) {
					case	'A': codetmp[no] = 0x00; break;
					case	'P': codetmp[no] = 0x01; break;
					case	'Z': codetmp[no] = 0x02; break;
					case	'L': codetmp[no] = 0x03; break;
					case	'G': codetmp[no] = 0x04; break;
					case	'I': codetmp[no] = 0x05; break;
					case	'T': codetmp[no] = 0x06; break;
					case	'Y': codetmp[no] = 0x07; break;
					case	'E': codetmp[no] = 0x08; break;
					case	'O': codetmp[no] = 0x09; break;
					case	'X': codetmp[no] = 0x0A; break;
					case	'U': codetmp[no] = 0x0B; break;
					case	'K': codetmp[no] = 0x0C; break;
					case	'S': codetmp[no] = 0x0D; break;
					case	'V': codetmp[no] = 0x0E; break;
					case	'N': codetmp[no] = 0x0F; break;
				}
			}

			if( no == 6 ) {
				// Address
				code.address |= (WORD)(codetmp[3] & 0x07)<<12;
				code.address |= (WORD)(codetmp[4] & 0x08)<< 8;
				code.address |= (WORD)(codetmp[5] & 0x07)<< 8;
				code.address |= (WORD)(codetmp[1] & 0x08)<< 4;
				code.address |= (WORD)(codetmp[2] & 0x07)<< 4;
				code.address |= (WORD)(codetmp[3] & 0x08);
				code.address |= (WORD)(codetmp[4] & 0x07);
				// Data
				code.data |= (codetmp[0] & 0x08)<<4;
				code.data |= (codetmp[1] & 0x07)<<4;
				code.data |= (codetmp[5] & 0x08);
				code.data |= (codetmp[0] & 0x07);

				m_GenieCode.push_back( code );
			} else
			if( no == 8 ) {
				// Address
				code.address |= 0x8000;
				code.address |= (WORD)(codetmp[3] & 0x07)<<12;
				code.address |= (WORD)(codetmp[4] & 0x08)<< 8;
				code.address |= (WORD)(codetmp[5] & 0x07)<< 8;
				code.address |= (WORD)(codetmp[1] & 0x08)<< 4;
				code.address |= (WORD)(codetmp[2] & 0x07)<< 4;
				code.address |= (WORD)(codetmp[3] & 0x08);
				code.address |= (WORD)(codetmp[4] & 0x07);
				// Data
				code.data |= (codetmp[0] & 0x08)<<4;
				code.data |= (codetmp[1] & 0x07)<<4;
				code.data |= (codetmp[7] & 0x08);
				code.data |= (codetmp[0] & 0x07);
				// Data
				code.cmp  |= (codetmp[6] & 0x08)<<4;
				code.cmp  |= (codetmp[7] & 0x07)<<4;
				code.cmp  |= (codetmp[5] & 0x08);
				code.cmp  |= (codetmp[6] & 0x07);

				m_GenieCode.push_back( code );
			}
		}

		GenieCodeProcess();
	}

	FCLOSE( fp );
}

void	NES::GenieCodeProcess()
{
	WORD	addr;

	for( INT i = 0; i < m_GenieCode.size(); i++ ) {
		addr = m_GenieCode[i].address;
		if( addr & 0x8000 ) {
		// 8character codes
			if( CPU_MEM_BANK[addr>>13][addr&0x1FFF] == m_GenieCode[i].cmp ) {
				CPU_MEM_BANK[addr>>13][addr&0x1FFF] = m_GenieCode[i].data;
			}
		} else {
		// 6character codes
			addr |= 0x8000;
			CPU_MEM_BANK[addr>>13][addr&0x1FFF] = m_GenieCode[i].data;
		}
	}
}

void	NES::DrawPad()
{
	if( m_bMoviePlay ) {
		INT	offset_h = 12;
		INT	offset_v = Config.graphics.bAllLine?(240-18):(240-22);

		DWORD	dwData = pad->GetSyncData();
		for( INT i = 0; i < 4; i++ ) {
			BYTE	Data = (BYTE)(dwData>>(i*8));
			if( m_MovieControl & (1<<i) ) {
				DrawBitmap( offset_h, offset_v, m_PadImg );

				// KEY
				if( Data&(1<<4) ) DrawBitmap( offset_h+3, offset_v+1, m_KeyImg0 ); // U
				if( Data&(1<<5) ) DrawBitmap( offset_h+3, offset_v+5, m_KeyImg0 ); // D
				if( Data&(1<<6) ) DrawBitmap( offset_h+1, offset_v+3, m_KeyImg0 ); // L
				if( Data&(1<<7) ) DrawBitmap( offset_h+5, offset_v+3, m_KeyImg0 ); // R

				// START,SELECT
				if( Data&(1<<2) ) DrawBitmap( offset_h+ 9, offset_v+5, m_KeyImg1 ); // SELECT
				if( Data&(1<<3) ) DrawBitmap( offset_h+13, offset_v+5, m_KeyImg1 ); // START

				// A,B
				if( Data&(1<<0) ) DrawBitmap( offset_h+23, offset_v+3, m_KeyImg2 ); // A
				if( Data&(1<<1) ) DrawBitmap( offset_h+18, offset_v+3, m_KeyImg2 ); // B

				offset_h += 30;
			}
		}

	}
}

void	NES::DrawBitmap( INT x, INT y, LPBYTE lpBitmap )
{
INT	i, j;
INT	h, v;
LPBYTE	pScn = ppu->GetScreenPtr()+8+(256+16)*y+x;
LPBYTE	pPtr;

	h = (INT)*lpBitmap++;
	v = (INT)*lpBitmap++;

	for( j = 0; j < v; j++ ) {
		pPtr = pScn;
		for( i = 0; i < h; i++ ) {
			if( *lpBitmap != 0xFF ) {
				*pPtr = *lpBitmap;
			}
			lpBitmap++;
			pPtr++;
		}
		pScn += 256+16;
	}
}


int SaveBitmapToFile(HBITMAP hbitmap , LPSTR lpfilename)
{ 
	HDC hdc;					//�豸������
	int ibits; 
	WORD wbitcount;				//��ǰ��ʾ�ֱ�����ÿ��������ռ�ֽ���

	//λͼ��ÿ��������ռ�ֽ����������ɫ���С��λͼ�������ֽڴ�С��λͼ�ļ���С ��д���ļ��ֽ���
	DWORD dwpalettesize=0, dwbmbitssize, dwdibsize, dwwritten;

	BITMAP bitmap;				//λͼ���Խṹ
	BITMAPFILEHEADER bmfhdr;	//λͼ�ļ�ͷ�ṹ
	BITMAPINFOHEADER bi;		//λͼ��Ϣͷ�ṹ
	LPBITMAPINFOHEADER lpbi;	//ָ��λͼ��Ϣͷ�ṹ

	//�����ļ��������ڴ�������ɫ����
	HANDLE fh, hdib, hpal,holdpal=NULL;

	//����λͼ�ļ�ÿ��������ռ�ֽ���
	hdc = CreateDC("display",NULL,NULL,NULL);
	ibits = GetDeviceCaps(hdc, BITSPIXEL) * GetDeviceCaps(hdc, PLANES);
	DeleteDC(hdc);

	if (ibits <= 1)
		wbitcount = 1;
	else if (ibits <= 4)
		wbitcount = 4;
	else if (ibits <= 8)
		wbitcount = 8;
	else if (ibits <= 16)
		wbitcount = 16;
	else if (ibits <= 24)
		wbitcount = 24;
	else 
		wbitcount = 32;

	//�����ɫ���С
	if (wbitcount <= 8)
		dwpalettesize = (1 << wbitcount) * sizeof(RGBQUAD);

	//����λͼ��Ϣͷ�ṹ
	GetObject(hbitmap, sizeof(BITMAP), (LPSTR)&bitmap);
	bi.biSize = sizeof(BITMAPINFOHEADER);
	bi.biWidth = bitmap.bmWidth;
	bi.biHeight = bitmap.bmHeight;
	bi.biPlanes = 1;
	bi.biBitCount = wbitcount;
	bi.biCompression = BI_RGB;
	bi.biSizeImage = 0;
	bi.biXPelsPerMeter = 0;
	bi.biYPelsPerMeter = 0;
	bi.biClrUsed = 0;
	bi.biClrImportant = 0;

	dwbmbitssize = ((bitmap.bmWidth * wbitcount+31)/32)* 4 * bitmap.bmHeight ;
	//Ϊλͼ���ݷ����ڴ�
	hdib = GlobalAlloc(GHND,dwbmbitssize + dwpalettesize + 
	sizeof(BITMAPINFOHEADER));
	lpbi = (LPBITMAPINFOHEADER)GlobalLock(hdib);
	*lpbi = bi;

	// ������ɫ�� 
	hpal = GetStockObject(DEFAULT_PALETTE);
	if (hpal)
	{
		hdc = ::GetDC(NULL);
		holdpal = SelectPalette(hdc, (HPALETTE)hpal, false);
		RealizePalette(hdc);
	}

	// ��ȡ�õ�ɫ�����µ�����ֵ
	GetDIBits(hdc, hbitmap, 0, (UINT) bitmap.bmHeight,(LPSTR)lpbi + 
	sizeof(BITMAPINFOHEADER)+dwpalettesize,(BITMAPINFO*)lpbi, DIB_RGB_COLORS);

	//�ָ���ɫ�� 
	if (holdpal)
	{
		SelectPalette(hdc, (HPALETTE)holdpal, true);
		RealizePalette(hdc);
		::ReleaseDC(NULL, hdc);
	}

	//����λͼ�ļ� 
	fh = CreateFile(lpfilename, GENERIC_WRITE, 0, NULL,
	  CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|
	FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (fh == INVALID_HANDLE_VALUE)
	return false;

	// ����λͼ�ļ�ͷ
	bmfhdr.bfType = 0x4d42; // "bm"
	dwdibsize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER)+ 
	dwpalettesize + dwbmbitssize; 
	bmfhdr.bfSize = dwdibsize;
	bmfhdr.bfReserved1 = 0;
	bmfhdr.bfReserved2 = 0;
	bmfhdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER)+ dwpalettesize;

	// д��λͼ�ļ�ͷ
	WriteFile(fh, (LPSTR)&bmfhdr, sizeof(BITMAPFILEHEADER), &dwwritten, NULL);

	// д��λͼ�ļ���������
	WriteFile(fh, (LPSTR)lpbi, dwdibsize, &dwwritten, NULL);

	//��� 
	GlobalUnlock(hdib);
	GlobalFree(hdib);
	CloseHandle(fh);

	return true;
}
