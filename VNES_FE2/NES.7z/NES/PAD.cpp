//////////////////////////////////////////////////////////////////////////
//                                                                      //
//      NES Pad                                                         //
//                                                           Norix      //
//                                               written     2001/02/22 //
//                                               last modify ----/--/-- //
//////////////////////////////////////////////////////////////////////////
#define	WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "typedef.h"
#include "macro.h"

#include "Config.h"

#include "DirectDraw.h"
#include "DirectInput.h"

#include "nes.h"
#include "pad.h"
#include "rom.h"

PAD::PAD( NES* parent ) : nes( parent )
{
	excontroller_select = 0;
	bStrobe = FALSE;

	padbit[0] = padbit[1] = padbit[2] = padbit[3] = 0;
	micbit = 0;
}

PAD::~PAD()
{
	DirectDraw.SetZapperMode( FALSE );
	DirectDraw.SetZapperDrawMode( FALSE );
}

void	PAD::Reset()
{
	pad1bit = pad2bit = 0;
	bStrobe = FALSE;

	bZapperMode = FALSE;

	ZeroMemory( padcnt, sizeof(padcnt) );

	// Select Extension Devices
	DWORD	crc = nes->rom->GetPROM_CRC();

	if( crc == 0xfbfc6a6c		// Adventures of Bayou Billy, The(E)
	 || crc == 0xcb275051		// Adventures of Bayou Billy, The(U)
	 || crc == 0xfb69c131		// Baby Boomer(Unl)(U)
	 || crc == 0xf2641ad0		// Barker Bill's Trick Shooting(U)
	 || crc == 0xbc1dce96		// Chiller (Unl)(U)
	 || crc == 0x90ca616d		// Duck Hunt(JUE)
	 || crc == 0x59e3343f		// Freedom Force(U)
	 || crc == 0x242a270c		// Gotcha!(U)
	 || crc == 0x7b5bd2de		// Gumshoe(UE)
	 || crc == 0x255b129c		// Gun Sight(J)
	 || crc == 0x8963ae6e		// Hogan's Alley(JU)
	 || crc == 0x51d2112f		// Laser Invasion(U)
	 || crc == 0x0a866c94		// Lone Ranger, The(U)
	 || crc == 0xe4c04eea		// Mad City(J)
	 || crc == 0x9eef47aa		// Mechanized Attack(U)
	 || crc == 0xc2db7551		// Shooting Range(U)
	 || crc == 0x163e86c0		// To The Earth(U)
	 || crc == 0x0d3cf705		// Wild Gunman(J)
	 || crc == 0x389960db ) {	// Wild Gunman(JUE)
		SetExController( EXCONTROLLER_ZAPPER );
	}
	if( crc == 0x35893b67		// Arkanoid(J)
	 || crc == 0x6267fbd1 ) {	// Arkanoid 2(J)
		SetExController( EXCONTROLLER_PADDLE );
	}
	if( crc == 0xff6621ce		// Hyper Olympic(J)
	 || crc == 0xdb9418e8		// Hyper Olympic(Tonosama Ban)(J)
	 || crc == 0xac98cd70 ) {	// Hyper Sports(J)
		SetExController( EXCONTROLLER_HYPERSHOT );
	}
	if( crc == 0xf9def527		// Family BASIC(Ver2.0)
	 || crc == 0xde34526e		// Family BASIC(Ver2.1a)
	 || crc == 0xf050b611		// Family BASIC(Ver3)
	 || crc == 0x3aaeed3f ) {	// Family BASIC(Ver3)(Alt)
		SetExController( EXCONTROLLER_KEYBOARD );
	}
	if( crc == 0xc68363f6 ) {	// Crazy Climber(J)
		SetExController( EXCONTROLLER_CRAZYCLIMBER );
	}
	if( crc == 0x20d22251 ) {	// Top rider(J)
		SetExController( EXCONTROLLER_TOPRIDER );
	}
	if( crc == 0x0cd00488 ) {	// Space Shadow(J)
		SetExController( EXCONTROLLER_SPACESHADOWGUN );
	}
}

void	PAD::SetExController( INT type )
{
	excontroller_select = type;

	bZapperMode = FALSE;
	DirectDraw.SetZapperMode( FALSE );
	DirectDraw.SetZapperDrawMode( FALSE );

}

DWORD	PAD::GetSyncData()
{
DWORD	ret;

	ret = (DWORD)padbit[0]|((DWORD)padbit[1]<<8)|((DWORD)padbit[2]<<16)|((DWORD)padbit[3]<<24);
	ret |= (DWORD)micbit<<8;

	return	ret;
}

void	PAD::SetSyncData( DWORD data )
{
	micbit = (BYTE)((data&0x00000400)>>8);
	padbit[0] = (BYTE) data;
	padbit[1] = (BYTE)(data>> 8);
	padbit[2] = (BYTE)(data>>16);
	padbit[3] = (BYTE)(data>>24);
}

DWORD	PAD::GetSyncExData()
{
DWORD	data = 0;

	return	data;
}

void	PAD::SetSyncExData( DWORD data )
{
//DEBUGOUT( "PAD::SetSyncExData\n" );
	switch( excontroller_select ) {
		case	EXCONTROLLER_ZAPPER:
		case	EXCONTROLLER_PADDLE:
		case	EXCONTROLLER_SPACESHADOWGUN:
			{
			LONG	x, y;
				if( data & 0x80000000 ) {
					x = -1;
					y = -1;
				} else {
					x = data & 0xFF;
					y = (data&0xFF00)>>8;
				}
				nes->SetZapperPos( x, y );
				DirectDraw.SetZapperPos( x, y );
			}
			break;
		case	EXCONTROLLER_CRAZYCLIMBER:
			break;
		case	EXCONTROLLER_TOPRIDER:
			break;
		default:
			break;
	}
}

void	PAD::Sync()
{
	padbit[0] = SyncSub( 0 );
	padbit[1] = SyncSub( 1 );
	padbit[2] = SyncSub( 2 );
	padbit[3] = SyncSub( 3 );

	// Mic
	micbit = 0;
	if( Config.controller.nButton[1][10] && DirectInput.m_Sw[Config.controller.nButton[1][10]]
	 || Config.controller.nButton[1][26] && DirectInput.m_Sw[Config.controller.nButton[1][26]] ) {
		micbit |= 0x04;
	}

	// For NSF
	NsfSub();
}

static	INT	ren30fps[] = {
	1, 0
};
static	INT	ren20fps[] = {
	1, 1, 0
};
static	INT	ren15fps[] = {
	1, 1, 0, 0
};
static	INT	ren10fps[] = {
	1, 1, 1, 0, 0, 0
};

static	INT	renmask[] = {
	6, 4, 3, 2,
};
static	INT*	rentbl[] = {
	ren10fps, ren15fps, ren20fps, ren30fps
};

BYTE	PAD::SyncSub( INT no )
{
WORD	bit = 0;

	// Up
	if( Config.controller.nButton[no][ 0] && DirectInput.m_Sw[Config.controller.nButton[no][ 0]]
	 || Config.controller.nButton[no][16] && DirectInput.m_Sw[Config.controller.nButton[no][16]] )
		bit |= 1<<4;
	// Down
	if( Config.controller.nButton[no][ 1] && DirectInput.m_Sw[Config.controller.nButton[no][ 1]]
	 || Config.controller.nButton[no][17] && DirectInput.m_Sw[Config.controller.nButton[no][17]] )
		bit |= 1<<5;
	// Left
	if( Config.controller.nButton[no][ 2] && DirectInput.m_Sw[Config.controller.nButton[no][ 2]]
	 || Config.controller.nButton[no][18] && DirectInput.m_Sw[Config.controller.nButton[no][18]] )
		bit |= 1<<6;
	// Right
	if( Config.controller.nButton[no][ 3] && DirectInput.m_Sw[Config.controller.nButton[no][ 3]]
	 || Config.controller.nButton[no][19] && DirectInput.m_Sw[Config.controller.nButton[no][19]] )
		bit |= 1<<7;

	// �������͂��֎~����
	if( (bit&((1<<4)|(1<<5))) == ((1<<4)|(1<<5)) )
		bit &= ~((1<<4)|(1<<5));
	if( (bit&((1<<6)|(1<<7))) == ((1<<6)|(1<<7)) )
		bit &= ~((1<<6)|(1<<7));

	// A,B
	if( Config.controller.nButton[no][ 4] && DirectInput.m_Sw[Config.controller.nButton[no][ 4]]
	 || Config.controller.nButton[no][20] && DirectInput.m_Sw[Config.controller.nButton[no][20]] )
		bit |= 1<<0;
	if( Config.controller.nButton[no][ 5] && DirectInput.m_Sw[Config.controller.nButton[no][ 5]]
	 || Config.controller.nButton[no][21] && DirectInput.m_Sw[Config.controller.nButton[no][21]] )
		bit |= 1<<1;

	// A,B Rapid
	if( Config.controller.nButton[no][ 6] && DirectInput.m_Sw[Config.controller.nButton[no][ 6]]
	 || Config.controller.nButton[no][22] && DirectInput.m_Sw[Config.controller.nButton[no][22]] )
		bit |= 1<<8;
	if( Config.controller.nButton[no][ 7] && DirectInput.m_Sw[Config.controller.nButton[no][ 7]]
	 || Config.controller.nButton[no][23] && DirectInput.m_Sw[Config.controller.nButton[no][23]] )
		bit |= 1<<9;

	// Start, Select
	if( Config.controller.nButton[no][ 8] && DirectInput.m_Sw[Config.controller.nButton[no][ 8]]
	 || Config.controller.nButton[no][24] && DirectInput.m_Sw[Config.controller.nButton[no][24]] )
		bit |= 1<<2;
	if( Config.controller.nButton[no][ 9] && DirectInput.m_Sw[Config.controller.nButton[no][ 9]]
	 || Config.controller.nButton[no][25] && DirectInput.m_Sw[Config.controller.nButton[no][25]] )
		bit |= 1<<3;

	// A rapid setup
	if( bit&(1<<8) ) {
		INT	spd = Config.controller.nRapid[no][0];
		if( spd >= 3 ) spd = 3;
		INT*	tbl = rentbl[spd];

		if( padcnt[no][0] >= renmask[spd] )
			padcnt[no][0] = 0;

		if( tbl[padcnt[no][0]] )
			bit |= (1<<0);
		else
			bit &= ~(1<<0);

		padcnt[no][0]++;
	} else {
		padcnt[no][0] = 0;
	}
	// B rapid setup
	if( bit&(1<<9) ) {
		INT	spd = Config.controller.nRapid[no][1];
		if( spd >= 3 ) spd = 3;
		INT*	tbl = rentbl[spd];

		if( padcnt[no][1] >= renmask[spd] )
			padcnt[no][1] = 0;

		if( tbl[padcnt[no][1]] )
			bit |= (1<<1);
		else
			bit &= ~(1<<1);

		padcnt[no][1]++;
	} else {
		padcnt[no][1] = 0;
	}

	return	(BYTE)(bit&0xFF);
}

void	PAD::Strobe()
{
	if( Config.emulator.bFourPlayer ) {
	// NES type
		pad1bit = (DWORD)padbit[0] | ((DWORD)padbit[2]<<8) | 0x00080000;
		pad2bit = (DWORD)padbit[1] | ((DWORD)padbit[3]<<8) | 0x00040000;
	} else {
	// Famicom type
		pad1bit = (DWORD)padbit[0];
		pad2bit = (DWORD)padbit[1];
	}
	pad3bit = (DWORD)padbit[2];
	pad4bit = (DWORD)padbit[3];
}

BYTE	PAD::Read( WORD addr )
{
BYTE	data = 0x00;

	if( addr == 0x4016 ) {
		data = (BYTE)pad1bit&1;
		pad1bit>>=1;
		data |= ((BYTE)pad3bit&1)<<1;
		pad3bit>>=1;
		// Mic
		data |= micbit;

	}
	if( addr == 0x4017 ) {
		data = (BYTE)pad2bit&1;
		pad2bit>>=1;
		data |= ((BYTE)pad4bit&1)<<1;
		pad4bit>>=1;

	}

	return	data;
}

void	PAD::Write( WORD addr, BYTE data )
{
	if( addr == 0x4016 ) {
		if( data&0x01 ) {
			bStrobe = TRUE;
		} else if( bStrobe ) {
			bStrobe = FALSE;

			Strobe();
		}

	}
}

void	PAD::NsfSub()
{
	nsfbit = 0;

	// Play
	if( Config.controller.nNsfButton[ 0] && DirectInput.m_Sw[Config.controller.nNsfButton[ 0]]
	 || Config.controller.nNsfButton[16] && DirectInput.m_Sw[Config.controller.nNsfButton[16]] )
		nsfbit |= 1<<0;
	// Stop
	if( Config.controller.nNsfButton[ 1] && DirectInput.m_Sw[Config.controller.nNsfButton[ 1]]
	 || Config.controller.nNsfButton[17] && DirectInput.m_Sw[Config.controller.nNsfButton[17]] )
		nsfbit |= 1<<1;

	// Number -1
	if( Config.controller.nNsfButton[ 2] && DirectInput.m_Sw[Config.controller.nNsfButton[ 2]]
	 || Config.controller.nNsfButton[18] && DirectInput.m_Sw[Config.controller.nNsfButton[18]] )
		nsfbit |= 1<<2;
	// Number +1
	if( Config.controller.nNsfButton[ 3] && DirectInput.m_Sw[Config.controller.nNsfButton[ 3]]
	 || Config.controller.nNsfButton[19] && DirectInput.m_Sw[Config.controller.nNsfButton[19]] )
		nsfbit |= 1<<3;
	// Number +16
	if( Config.controller.nNsfButton[ 4] && DirectInput.m_Sw[Config.controller.nNsfButton[ 4]]
	 || Config.controller.nNsfButton[20] && DirectInput.m_Sw[Config.controller.nNsfButton[20]] )
		nsfbit |= 1<<4;
	// Number -16
	if( Config.controller.nNsfButton[ 5] && DirectInput.m_Sw[Config.controller.nNsfButton[ 5]]
	 || Config.controller.nNsfButton[21] && DirectInput.m_Sw[Config.controller.nNsfButton[21]] )
		nsfbit |= 1<<5;

	// �������͂��֎~����
	if( (nsfbit&((1<<2)|(1<<3))) == ((1<<2)|(1<<3)) )
		nsfbit &= ~((1<<2)|(1<<3));
	if( (nsfbit&((1<<4)|(1<<5))) == ((1<<4)|(1<<5)) )
		nsfbit &= ~((1<<4)|(1<<5));
}
