//////////////////////////////////////////////////////////////////////////
//                                                                      //
//      NES APU core                                                    //
//                                                           Norix      //
//                                               written     2002/06/27 //
//                                               last modify ----/--/-- //
//////////////////////////////////////////////////////////////////////////
#include "App.h"
#include "Config.h"

#include "nes.h"
#include "mmu.h"
#include "cpu.h"
#include "ppu.h"
#include "rom.h"
#include "apu.h"

// Volume adjust
// Internal sounds
#define	RECTANGLE_VOL	(0x0F0)
#define	TRIANGLE_VOL	(0x130)
#define	NOISE_VOL	(0x0C0)
#define	DPCM_VOL	(0x0F0)
// Extra sounds
#define	VRC6_VOL	(0x0F0)
#define	VRC7_VOL	(0x130)
#define	FDS_VOL		(0x0F0)
#define	MMC5_VOL	(0x0F0)
#define	N106_VOL	(0x088)
#define	FME7_VOL	(0x130)

APU::QUEUE	APU::queue;
APU::QUEUE	APU::exqueue;

APU::APU( NES* parent )
{
	exsound_select = 0;

	nes = parent;
	internal.SetParent( parent );

	last_data = last_diff = 0;

	ZEROMEMORY( m_SoundBuffer, sizeof(m_SoundBuffer) );

	ZEROMEMORY( lowpass_filter, sizeof(lowpass_filter) );
	ZEROMEMORY( &queue, sizeof(queue) );
	ZEROMEMORY( &exqueue, sizeof(exqueue) );

	for( INT i = 0; i < 16; i++ ) {
		m_bMute[i] = TRUE;
	}
}

APU::~APU()
{
}

void	APU::SetQueue( INT writetime, WORD addr, BYTE data )
{
	queue.data[queue.wrptr].time = writetime;
	queue.data[queue.wrptr].addr = addr;
	queue.data[queue.wrptr].data = data;
	queue.wrptr++;
	queue.wrptr&=QUEUE_LENGTH-1;
}

BOOL	APU::GetQueue( INT writetime, QUEUEDATA& ret )
{
	if( queue.wrptr == queue.rdptr ) {
		return	FALSE;
	}
	if( queue.data[queue.rdptr].time <= writetime ) {
		ret = queue.data[queue.rdptr];
		queue.rdptr++;
		queue.rdptr&=QUEUE_LENGTH-1;
		return	TRUE;
	}
	return	FALSE;
}

void	APU::SetExQueue( INT writetime, WORD addr, BYTE data )
{
	exqueue.data[exqueue.wrptr].time = writetime;
	exqueue.data[exqueue.wrptr].addr = addr;
	exqueue.data[exqueue.wrptr].data = data;
	exqueue.wrptr++;
	exqueue.wrptr&=QUEUE_LENGTH-1;
}

BOOL	APU::GetExQueue( INT writetime, QUEUEDATA& ret )
{
	if( exqueue.wrptr == exqueue.rdptr ) {
		return	FALSE;
	}
	if( exqueue.data[exqueue.rdptr].time <= writetime ) {
		ret = exqueue.data[exqueue.rdptr];
		exqueue.rdptr++;
		exqueue.rdptr&=QUEUE_LENGTH-1;
		return	TRUE;
	}
	return	FALSE;
}

void	APU::QueueFlush()
{
	while( queue.wrptr != queue.rdptr ) {
		WriteProcess( queue.data[queue.rdptr].addr, queue.data[queue.rdptr].data );
		queue.rdptr++;
		queue.rdptr&=QUEUE_LENGTH-1;
	}

	while( exqueue.wrptr != exqueue.rdptr ) {
		WriteExProcess( exqueue.data[queue.rdptr].addr, exqueue.data[queue.rdptr].data );
		exqueue.rdptr++;
		exqueue.rdptr&=QUEUE_LENGTH-1;
	}
}

void	APU::WriteExProcess( WORD addr, BYTE data )
{
}

void	APU::SoundSetup()
{
	FLOAT	fClock = nes->nescfg->CpuClock;
	INT	nRate = (INT)Config.sound.nRate;
	internal.Setup( fClock, nRate );
}

void	APU::Reset()
{
	ZEROMEMORY( &queue, sizeof(queue) );
	ZEROMEMORY( &exqueue, sizeof(exqueue) );

	elapsed_time = 0;

	FLOAT	fClock = nes->nescfg->CpuClock;
	INT	nRate = (INT)Config.sound.nRate;
	internal.Reset( fClock, nRate );

	SoundSetup();
}

void	APU::SelectExSound( BYTE data )
{
	exsound_select = data;
}

BYTE	APU::Read( WORD addr )
{
	return	internal.SyncRead( addr );
}

void	APU::Write( WORD addr, BYTE data )
{
	// $4018��VirtuaNES�ŗL�|�[�g
	if( addr >= 0x4000 && addr <= 0x401F ) {
		internal.SyncWrite( addr, data );
		SetQueue( nes->cpu->GetTotalCycles(), addr, data );
	}
}

BYTE	APU::ExRead( WORD addr )
{
BYTE	data = 0;

	if( exsound_select & 0x10 ) {
		if( addr == 0x4800 ) {
			SetExQueue( nes->cpu->GetTotalCycles(), 0, 0 );
		}
	}

	return	data;
}

void	APU::ExWrite( WORD addr, BYTE data )
{
	SetExQueue( nes->cpu->GetTotalCycles(), addr, data );
}

void	APU::Sync()
{
}

void	APU::SyncDPCM( INT cycles )
{
	if( internal.Sync( cycles ) ) {
		nes->cpu->IRQ_NotPending();
	}
}

void	APU::WriteProcess( WORD addr, BYTE data )
{
	// $4018��VirtuaNES�ŗL�|�[�g
	if( addr >= 0x4000 && addr <= 0x401F ) {
		internal.Write( addr, data );
	}
}

void	APU::Process( LPBYTE lpBuffer, DWORD dwSize )
{
INT	nBits = Config.sound.nBits;
DWORD	dwLength = dwSize / (nBits/8);
INT	output;
QUEUEDATA q;
DWORD	writetime;

LPSHORT	pSoundBuf = m_SoundBuffer;
INT	nCcount = 0;

INT	nFilterType = Config.sound.nFilterType;

	if( !Config.sound.bEnable ) {
		::FillMemory( lpBuffer, dwSize, (BYTE)(Config.sound.nRate==8?128:0) );
		return;
	}

	// Volume setup
	//  0:Master
	//  1:Rectangle 1
	//  2:Rectangle 2
	//  3:Triangle
	//  4:Noise
	//  5:DPCM
	//  6:VRC6
	//  7:VRC7
	//  8:FDS
	//  9:MMC5
	// 10:N106
	// 11:FME7
	INT	vol[24];
	BOOL*	bMute = m_bMute;
	SHORT*	nVolume = Config.sound.nVolume;

	INT	nMasterVolume = bMute[0]?nVolume[0]:0;

	// Internal
	vol[ 0] = bMute[1]?(RECTANGLE_VOL*nVolume[1]*nMasterVolume)/(100*100):0;
	vol[ 1] = bMute[2]?(RECTANGLE_VOL*nVolume[2]*nMasterVolume)/(100*100):0;
	vol[ 2] = bMute[3]?(TRIANGLE_VOL *nVolume[3]*nMasterVolume)/(100*100):0;
	vol[ 3] = bMute[4]?(NOISE_VOL    *nVolume[4]*nMasterVolume)/(100*100):0;
	vol[ 4] = bMute[5]?(DPCM_VOL     *nVolume[5]*nMasterVolume)/(100*100):0;

	// VRC6
	vol[ 5] = bMute[6]?(VRC6_VOL*nVolume[6]*nMasterVolume)/(100*100):0;
	vol[ 6] = bMute[7]?(VRC6_VOL*nVolume[6]*nMasterVolume)/(100*100):0;
	vol[ 7] = bMute[8]?(VRC6_VOL*nVolume[6]*nMasterVolume)/(100*100):0;

	// VRC7
	vol[ 8] = bMute[6]?(VRC7_VOL*nVolume[7]*nMasterVolume)/(100*100):0;

	// FDS
	vol[ 9] = bMute[6]?(FDS_VOL*nVolume[8]*nMasterVolume)/(100*100):0;

	// MMC5
	vol[10] = bMute[6]?(MMC5_VOL*nVolume[9]*nMasterVolume)/(100*100):0;
	vol[11] = bMute[7]?(MMC5_VOL*nVolume[9]*nMasterVolume)/(100*100):0;
	vol[12] = bMute[8]?(MMC5_VOL*nVolume[9]*nMasterVolume)/(100*100):0;

	// N106
	vol[13] = bMute[ 6]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[14] = bMute[ 7]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[15] = bMute[ 8]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[16] = bMute[ 9]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[17] = bMute[10]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[18] = bMute[11]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[19] = bMute[12]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;
	vol[20] = bMute[13]?(N106_VOL*nVolume[10]*nMasterVolume)/(100*100):0;

	// FME7
	vol[21] = bMute[6]?(FME7_VOL*nVolume[11]*nMasterVolume)/(100*100):0;
	vol[22] = bMute[7]?(FME7_VOL*nVolume[11]*nMasterVolume)/(100*100):0;
	vol[23] = bMute[8]?(FME7_VOL*nVolume[11]*nMasterVolume)/(100*100):0;

//	double	cycle_rate = ((double)FRAME_CYCLES*60.0/12.0)/(double)Config.sound.nRate;
	double	cycle_rate = ((double)nes->nescfg->FrameCycles*60.0/12.0)/(double)Config.sound.nRate;

	// CPU�T�C�N���������[�v���Ă��܂������̑΍􏈗�
	if( elapsed_time > nes->cpu->GetTotalCycles() ) {
		QueueFlush();
	}

	while( dwLength-- ) {
		writetime = (DWORD)elapsed_time;

		while( GetQueue( writetime, q ) ) {
			WriteProcess( q.addr, q.data );
		}

		while( GetExQueue( writetime, q ) ) {
			WriteExProcess( q.addr, q.data );
		}

		// 0-4:internal 5-7:VRC6 8:VRC7 9:FDS 10-12:MMC5 13-20:N106 21-23:FME7
		output = 0;
		output += internal.Process( 0 )*vol[0];
		output += internal.Process( 1 )*vol[1];
		output += internal.Process( 2 )*vol[2];
		output += internal.Process( 3 )*vol[3];
		output += internal.Process( 4 )*vol[4];

		output >>= 8;

		if( nFilterType == 1 ) {
			//���[�p�X�t�B���^�[TYPE 1(Simple)
			output = (lowpass_filter[0]+output)/2;
			lowpass_filter[0] = output;
		} else if( nFilterType == 2 ) {
			//���[�p�X�t�B���^�[TYPE 2(Weighted type 1)
			output = (lowpass_filter[1]+lowpass_filter[0]+output)/3;
			lowpass_filter[1] = lowpass_filter[0];
			lowpass_filter[0] = output;
		} else if( nFilterType == 3 ) {
			//���[�p�X�t�B���^�[TYPE 3(Weighted type 2)
			output = (lowpass_filter[2]+lowpass_filter[1]+lowpass_filter[0]+output)/4;
			lowpass_filter[2] = lowpass_filter[1];
			lowpass_filter[1] = lowpass_filter[0];
			lowpass_filter[0] = output;
		} else if( nFilterType == 4 ) {
			//���[�p�X�t�B���^�[TYPE 4(Weighted type 3)
			output = (lowpass_filter[1]+lowpass_filter[0]*2+output)/4;
			lowpass_filter[1] = lowpass_filter[0];
			lowpass_filter[0] = output;
		}

#if	1
		// DC�����̃J�b�g
		{
		static double ave = 0.0, max=0.0, min=0.0;
		double delta;
		delta = (max-min)/32768.0;
		max -= delta;
		min += delta;
		if( output > max ) max = output;
		if( output < min ) min = output;
		ave -= ave/1024.0;
		ave += (max+min)/2048.0;
		output -= (INT)ave;
		}
#endif
#if	0
		// DC�����̃J�b�g(HPF TEST)
		{
		static	double	cutoff = (2.0*3.141592653579*10.0/44100.0);
		static	double	tmp = 0.0;
		double	in, out;

		in = (double)output;
		out = (in - tmp);
		tmp = tmp + cutoff * out;

		output = (INT)out;
		}
#endif
#if	0
		// �X�p�C�N�m�C�Y�̏���(AGC TEST)
		{
		INT	diff = abs(output-last_data);
		if( diff > 0x4000 ) {
			output /= 4;
		} else 
		if( diff > 0x3000 ) {
			output /= 3;
		} else
		if( diff > 0x2000 ) {
			output /= 2;
		}
		last_data = output;
		}
#endif
		// Limit
		if( output > 0x7FFF ) {
			output = 0x7FFF;
		} else if( output < -0x8000 ) {
			output = -0x8000;
		}

		if( nBits != 8 ) {
			*(SHORT*)lpBuffer = (SHORT)output;
			lpBuffer += sizeof(SHORT);
		} else {
			*lpBuffer++ = (output>>8)^0x80;
		}

		if( nCcount < 0x0100 )
			pSoundBuf[nCcount++] = (SHORT)output;

//		elapsedtime += cycle_rate;
		elapsed_time += cycle_rate;
	}

#if	1
	if( elapsed_time > ((nes->nescfg->FrameCycles/24)+nes->cpu->GetTotalCycles()) ) {
		elapsed_time = nes->cpu->GetTotalCycles();
	}
	if( (elapsed_time+(nes->nescfg->FrameCycles/6)) < nes->cpu->GetTotalCycles() ) {
		elapsed_time = nes->cpu->GetTotalCycles();
	}
#else
	elapsed_time = nes->cpu->GetTotalCycles();
#endif
}

// �`�����l���̎��g���擾�T�u���[�`��(NSF�p)
INT	APU::GetChannelFrequency( INT no )
{
	// Internal
	if( no < 5 )
		return	internal.GetFreq( no );
	return	0;
}

